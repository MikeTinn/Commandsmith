# CommandSmith
Client-side Fabric mod for Minecraft 1.21.11. Open it from Mod Menu -> CommandSmith -> Configure.
Part 1: /give command generator. Part 2 (later): LuckPerms ranks.

Build: push to GitHub (Actions builds the jar) or run `gradle build` with Java 21.
If you already have a working gradlew/gradle wrapper from another repo, copy it in and
swap versions in gradle.properties to match.
