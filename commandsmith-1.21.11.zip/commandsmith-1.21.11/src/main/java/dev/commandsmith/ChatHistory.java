package dev.commandsmith;

import net.minecraft.client.GuiMessage;
import net.minecraft.client.Minecraft;

import java.util.ArrayList;
import java.util.List;

/** Reads the lines currently in the client's chat history (oldest first). */
public final class ChatHistory {
    private ChatHistory() {}

    public static List<String> lines(int max) {
        List<String> out = new ArrayList<>();
        Minecraft mc = Minecraft.getInstance();
        if (mc.gui == null) return out;
        List<GuiMessage> all = mc.gui.getChat().allMessages; // made accessible by commandsmith.accesswidener
        if (all.isEmpty()) return out;
        // the game stores newest first; check instead of assuming
        boolean newestFirst = all.size() < 2 || all.get(0).addedTime() >= all.get(all.size() - 1).addedTime();
        for (int k = 0; k < all.size(); k++) {
            GuiMessage m = newestFirst ? all.get(all.size() - 1 - k) : all.get(k);
            for (String part : m.content().getString().split("\n")) {
                String t = part.trim();
                if (!t.isEmpty()) out.add(t);
            }
        }
        return out.size() > max ? new ArrayList<>(out.subList(out.size() - max, out.size())) : out;
    }
}
