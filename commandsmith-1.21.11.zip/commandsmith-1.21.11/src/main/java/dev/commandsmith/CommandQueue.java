package dev.commandsmith;

import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * Queue of commands that keeps running even after the screen is closed.
 * A background timer only pokes the main thread; everything else happens on the main thread.
 */
public final class CommandQueue {
    public static final class Item {
        public final String label;
        public final String command;
        public boolean sent;

        Item(String label, String command) {
            this.label = label;
            this.command = command;
        }
    }

    /** Main thread only. */
    public static final List<Item> ITEMS = new ArrayList<>();
    public static boolean running;

    private static long nextAt;
    private static ScheduledExecutorService timer;

    private CommandQueue() {}

    public static void init() {
        if (timer != null) return;
        timer = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "commandsmith-queue");
            t.setDaemon(true);
            return t;
        });
        timer.scheduleAtFixedRate(() -> Minecraft.getInstance().execute(CommandQueue::pump), 100, 50, TimeUnit.MILLISECONDS);
    }

    public static void add(String label, String command) {
        ITEMS.add(new Item(label, command));
    }

    public static int pending() {
        int n = 0;
        for (Item i : ITEMS) if (!i.sent) n++;
        return n;
    }

    public static int sent() {
        return ITEMS.size() - pending();
    }

    public static void start() {
        if (pending() == 0) return;
        running = true;
        nextAt = 0;
    }

    public static void pause() {
        running = false;
    }

    public static void clearSent() {
        ITEMS.removeIf(i -> i.sent);
    }

    public static void clearAll() {
        ITEMS.clear();
        running = false;
    }

    private static void pump() {
        if (!running) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) {          // left the world: pause, keep the rest
            running = false;
            return;
        }
        long now = System.currentTimeMillis();
        if (now < nextAt) return;

        int pending = pending();
        if (pending == 0) {
            running = false;
            return;
        }
        int n;
        switch (CommandSmithConfig.queueMode) {
            case 0: n = pending; break;                                   // all at once
            case 1: n = Math.max(1, CommandSmithConfig.batchSize); break; // a few at a time
            default: n = 1; break;                                        // one by one
        }
        int sentNow = 0;
        for (Item it : ITEMS) {
            if (it.sent) continue;
            if (sentNow >= n) break;
            mc.player.connection.sendCommand(it.command);
            it.sent = true;
            sentNow++;
        }
        nextAt = now + (long) (Math.max(0, CommandSmithConfig.delaySec) * 1000.0);

        if (pending() == 0) {
            running = false;
            mc.player.displayClientMessage(Component.literal("[CommandSmith] Queue finished - " + sent() + " commands sent"), true);
        }
    }
}
