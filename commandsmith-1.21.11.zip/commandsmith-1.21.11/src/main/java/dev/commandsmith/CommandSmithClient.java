package dev.commandsmith;

import net.fabricmc.api.ClientModInitializer;

public class CommandSmithClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        CommandSmithConfig.load();
        dev.commandsmith.data.PresetStore.load();
        CommandQueue.init();
    }
}
