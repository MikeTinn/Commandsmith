package dev.commandsmith;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.file.Files;
import java.nio.file.Path;

public final class CommandSmithConfig {
    private static final Logger LOG = LoggerFactory.getLogger("commandsmith");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public static String target = "@s";
    public static boolean showAllEnchants = false;
    public static boolean unsafeLevels = false;

    // ranks / queue
    public static String rank = "";
    public static String duration = "7d";
    /** 0 = all at once, 1 = batches, 2 = one by one */
    public static int queueMode = 1;
    public static int batchSize = 3;
    public static double delaySec = 1.0;
    /** comma separated, most recent first */
    public static String recentRanks = "";

    private CommandSmithConfig() {}

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("commandsmith.json");
    }

    public static void load() {
        try {
            Path f = file();
            if (!Files.exists(f)) return;
            JsonObject o = JsonParser.parseString(Files.readString(f)).getAsJsonObject();
            if (o.has("target")) target = o.get("target").getAsString();
            if (o.has("showAllEnchants")) showAllEnchants = o.get("showAllEnchants").getAsBoolean();
            if (o.has("unsafeLevels")) unsafeLevels = o.get("unsafeLevels").getAsBoolean();
            if (o.has("rank")) rank = o.get("rank").getAsString();
            if (o.has("duration")) duration = o.get("duration").getAsString();
            if (o.has("queueMode")) queueMode = Math.max(0, Math.min(2, o.get("queueMode").getAsInt()));
            if (o.has("batchSize")) batchSize = Math.max(1, o.get("batchSize").getAsInt());
            if (o.has("delaySec")) delaySec = Math.max(0, o.get("delaySec").getAsDouble());
            if (o.has("recentRanks")) recentRanks = o.get("recentRanks").getAsString();
        } catch (Exception e) {
            LOG.warn("Could not read config", e);
        }
    }

    public static void save() {
        try {
            JsonObject o = new JsonObject();
            o.addProperty("target", target);
            o.addProperty("showAllEnchants", showAllEnchants);
            o.addProperty("unsafeLevels", unsafeLevels);
            o.addProperty("rank", rank);
            o.addProperty("duration", duration);
            o.addProperty("queueMode", queueMode);
            o.addProperty("batchSize", batchSize);
            o.addProperty("delaySec", delaySec);
            o.addProperty("recentRanks", recentRanks);
            Files.writeString(file(), GSON.toJson(o));
        } catch (Exception e) {
            LOG.warn("Could not save config", e);
        }
    }
}
