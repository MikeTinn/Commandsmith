package dev.commandsmith;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.file.Files;
import java.nio.file.Path;

public final class CommandSmithConfig {
    private static final Logger LOG = LoggerFactory.getLogger("commandsmith");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public static String target = "@s";
    public static boolean showAllEnchants = false;
    public static boolean unsafeLevels = false;

    private CommandSmithConfig() {}

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("commandsmith.json");
    }

    public static void load() {
        try {
            Path f = file();
            if (!Files.exists(f)) return;
            JsonObject o = JsonParser.parseString(Files.readString(f)).getAsJsonObject();
            if (o.has("target")) target = o.get("target").getAsString();
            if (o.has("showAllEnchants")) showAllEnchants = o.get("showAllEnchants").getAsBoolean();
            if (o.has("unsafeLevels")) unsafeLevels = o.get("unsafeLevels").getAsBoolean();
        } catch (Exception e) {
            LOG.warn("Could not read config", e);
        }
    }

    public static void save() {
        try {
            JsonObject o = new JsonObject();
            o.addProperty("target", target);
            o.addProperty("showAllEnchants", showAllEnchants);
            o.addProperty("unsafeLevels", unsafeLevels);
            Files.writeString(file(), GSON.toJson(o));
        } catch (Exception e) {
            LOG.warn("Could not save config", e);
        }
    }
}
