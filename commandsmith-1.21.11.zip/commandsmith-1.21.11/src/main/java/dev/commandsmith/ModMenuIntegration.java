package dev.commandsmith;

import com.terraformersmc.modmenu.api.ConfigScreenFactory;
import com.terraformersmc.modmenu.api.ModMenuApi;
import dev.commandsmith.gui.GeneratorScreen;

/** The "Configure" button in Mod Menu opens the generator. */
public class ModMenuIntegration implements ModMenuApi {
    @Override
    public ConfigScreenFactory<?> getModConfigScreenFactory() {
        return parent -> new GeneratorScreen(parent);
    }
}
