package dev.commandsmith.data;

import com.google.gson.JsonObject;

import java.math.BigDecimal;
import java.math.RoundingMode;

/** One attribute modifier entry for the attribute_modifiers component. */
public final class AttrMod {
    public String attribute = "attack_damage";
    public double amount = 1;
    /** add_value | add_multiplied_base | add_multiplied_total */
    public String operation = "add_value";
    /** any | hand | mainhand | offhand | armor | head | chest | legs | feet */
    public String slot = "any";

    public AttrMod copy() {
        AttrMod m = new AttrMod();
        m.attribute = attribute;
        m.amount = amount;
        m.operation = operation;
        m.slot = slot;
        return m;
    }

    public JsonObject toJson() {
        JsonObject o = new JsonObject();
        o.addProperty("attribute", attribute);
        o.addProperty("amount", amount);
        o.addProperty("operation", operation);
        o.addProperty("slot", slot);
        return o;
    }

    public static AttrMod fromJson(JsonObject o) {
        AttrMod m = new AttrMod();
        if (o.has("attribute")) m.attribute = o.get("attribute").getAsString();
        if (o.has("amount")) m.amount = o.get("amount").getAsDouble();
        if (o.has("operation")) m.operation = o.get("operation").getAsString();
        if (o.has("slot")) m.slot = o.get("slot").getAsString();
        return m;
    }

    public static String format(double v) {
        return new BigDecimal(v).setScale(3, RoundingMode.HALF_UP).stripTrailingZeros().toPlainString();
    }

    public String amountText() {
        return format(amount);
    }

    /** Short human summary, e.g. "+10", "+50% base", "+50% total". */
    public String summary() {
        String sign = amount >= 0 ? "+" : "";
        switch (operation) {
            case "add_multiplied_base": return sign + format(amount * 100) + "% base";
            case "add_multiplied_total": return sign + format(amount * 100) + "% total";
            default: return sign + amountText();
        }
    }
}
