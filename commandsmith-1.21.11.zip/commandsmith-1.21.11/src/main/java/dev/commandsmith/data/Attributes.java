package dev.commandsmith.data;

import java.util.List;

public final class Attributes {
    public record Attr(String id, String name) {}

    public static final List<Attr> ALL = List.of(
        new Attr("attack_damage", "Attack Damage"),
        new Attr("attack_speed", "Attack Speed"),
        new Attr("attack_knockback", "Attack Knockback"),
        new Attr("max_health", "Max Health"),
        new Attr("armor", "Armor"),
        new Attr("armor_toughness", "Armor Toughness"),
        new Attr("knockback_resistance", "Knockback Resistance"),
        new Attr("movement_speed", "Movement Speed"),
        new Attr("sneaking_speed", "Sneaking Speed"),
        new Attr("jump_strength", "Jump Strength"),
        new Attr("step_height", "Step Height"),
        new Attr("safe_fall_distance", "Safe Fall Distance"),
        new Attr("fall_damage_multiplier", "Fall Damage Multiplier"),
        new Attr("gravity", "Gravity"),
        new Attr("scale", "Scale (size)"),
        new Attr("luck", "Luck"),
        new Attr("block_interaction_range", "Block Reach"),
        new Attr("entity_interaction_range", "Entity Reach"),
        new Attr("mining_efficiency", "Mining Efficiency"),
        new Attr("block_break_speed", "Block Break Speed"),
        new Attr("submerged_mining_speed", "Underwater Mining Speed"),
        new Attr("oxygen_bonus", "Oxygen Bonus"),
        new Attr("water_movement_efficiency", "Water Movement"),
        new Attr("movement_efficiency", "Movement Efficiency"),
        new Attr("burning_time", "Burning Time"),
        new Attr("explosion_knockback_resistance", "Explosion KB Resistance"),
        new Attr("sweeping_damage_ratio", "Sweeping Damage Ratio")
    );

    public static String nameOf(String id) {
        for (Attr a : ALL) if (a.id().equals(id)) return a.name();
        return id;
    }

    public static int indexOf(String id) {
        for (int i = 0; i < ALL.size(); i++) if (ALL.get(i).id().equals(id)) return i;
        return 0;
    }

    /** Sensible default slot for an item group (see ItemCatalog groups). */
    public static String defaultSlot(String group) {
        switch (group) {
            case "helmet": return "head";
            case "chestplate": case "elytra": return "chest";
            case "leggings": return "legs";
            case "boots": return "feet";
            case "sword": case "axe": case "pickaxe": case "shovel": case "hoe": case "bow":
            case "crossbow": case "trident": case "mace": case "spear": case "fishing_rod": case "shears":
                return "mainhand";
            case "shield": return "offhand";
            default: return "any";
        }
    }

    private Attributes() {}
}
