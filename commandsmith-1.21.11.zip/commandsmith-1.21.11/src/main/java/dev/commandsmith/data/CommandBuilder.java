package dev.commandsmith.data;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Pure logic (no Minecraft classes) so the rank tool can reuse the same style later. */
public final class CommandBuilder {
    public String itemId = "minecraft:diamond_sword";
    public String target = "@s";
    public int count = 1;
    public final StyledText name = new StyledText(0xFFFFFF);
    /** Lore lines, each with its own gradient/formatting. */
    public final List<StyledText> lore = new ArrayList<>();
    public boolean unbreakable, glint;
    /** enchant id without namespace -> level */
    public final Map<String, Integer> enchants = new LinkedHashMap<>();

    /** Lore without trailing blank lines (blank lines in the middle are kept as spacers). */
    public List<StyledText> loreForOutput() {
        int last = -1;
        for (int i = 0; i < lore.size(); i++) if (!lore.get(i).isBlank()) last = i;
        return new ArrayList<>(lore.subList(0, last + 1));
    }

    /** Builds the command WITHOUT the leading slash. */
    public String build() {
        List<String> parts = new ArrayList<>();

        if (!name.isBlank()) parts.add("custom_name=" + name.toSnbt());

        List<StyledText> ls = loreForOutput();
        if (!ls.isEmpty()) {
            List<String> comps = new ArrayList<>();
            for (StyledText l : ls) comps.add(l.toSnbt());
            parts.add("lore=[" + String.join(",", comps) + "]");
        }

        if (!enchants.isEmpty()) {
            List<String> es = new ArrayList<>();
            for (Map.Entry<String, Integer> e : enchants.entrySet()) {
                es.add("\"minecraft:" + e.getKey() + "\":" + e.getValue());
            }
            parts.add("enchantments={" + String.join(",", es) + "}");
        }

        if (unbreakable) parts.add("unbreakable={}");
        if (glint) parts.add("enchantment_glint_override=true");

        String tgt = target == null || target.isBlank() ? "@s" : target.trim();
        StringBuilder sb = new StringBuilder("give ").append(tgt).append(' ').append(itemId);
        if (!parts.isEmpty()) sb.append('[').append(String.join(",", parts)).append(']');
        if (count > 1) sb.append(' ').append(count);
        return sb.toString();
    }
}
