package dev.commandsmith.data;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Pure logic (no Minecraft classes) so the rank tool can reuse the same style later. */
public final class CommandBuilder {
    public static final String[] COLOR_NAMES = {
        "black", "dark_blue", "dark_green", "dark_aqua", "dark_red", "dark_purple", "gold", "gray",
        "dark_gray", "blue", "green", "aqua", "red", "light_purple", "yellow", "white"
    };
    public static final int[] COLOR_RGB = {
        0x000000, 0x0000AA, 0x00AA00, 0x00AAAA, 0xAA0000, 0xAA00AA, 0xFFAA00, 0xAAAAAA,
        0x555555, 0x5555FF, 0x55FF55, 0x55FFFF, 0xFF5555, 0xFF55FF, 0xFFFF55, 0xFFFFFF
    };

    public String itemId = "minecraft:diamond_sword";
    public String target = "@s";
    public int count = 1;
    public String name = "";
    public int colorIndex = 15;
    public boolean bold, italic, unbreakable, glint;
    public String lore = "";
    /** enchant id without namespace -> level */
    public final Map<String, Integer> enchants = new LinkedHashMap<>();

    public List<String> loreLines() {
        List<String> out = new ArrayList<>();
        for (String s : lore.split("\\|")) {
            String t = s.trim();
            if (!t.isEmpty()) out.add(t);
        }
        return out;
    }

    /** Builds the command WITHOUT the leading slash. */
    public String build() {
        List<String> parts = new ArrayList<>();

        if (!name.isBlank()) {
            parts.add("custom_name=" + component(name.trim(), COLOR_NAMES[colorIndex], bold, italic));
        }

        List<String> loreLines = loreLines();
        if (!loreLines.isEmpty()) {
            List<String> comps = new ArrayList<>();
            for (String l : loreLines) comps.add(component(l, "gray", false, false));
            parts.add("lore=[" + String.join(",", comps) + "]");
        }

        if (!enchants.isEmpty()) {
            List<String> es = new ArrayList<>();
            for (Map.Entry<String, Integer> e : enchants.entrySet()) {
                es.add("\"minecraft:" + e.getKey() + "\":" + e.getValue());
            }
            parts.add("enchantments={" + String.join(",", es) + "}");
        }

        if (unbreakable) parts.add("unbreakable={}");
        if (glint) parts.add("enchantment_glint_override=true");

        String tgt = target == null || target.isBlank() ? "@s" : target.trim();
        StringBuilder sb = new StringBuilder("give ").append(tgt).append(' ').append(itemId);
        if (!parts.isEmpty()) sb.append('[').append(String.join(",", parts)).append(']');
        if (count > 1) sb.append(' ').append(count);
        return sb.toString();
    }

    private static String component(String text, String color, boolean bold, boolean italic) {
        StringBuilder sb = new StringBuilder("{text:\"").append(esc(text)).append("\",color:\"").append(color).append('"');
        if (bold) sb.append(",bold:true");
        sb.append(",italic:").append(italic);
        return sb.append('}').toString();
    }

    private static String esc(String s) {
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }
}
