package dev.commandsmith.data;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Pure logic (no Minecraft classes) so the rank tool can reuse the same style later. */
public final class CommandBuilder {
    public String itemId = "minecraft:diamond_sword";
    public String target = "@s";
    public int count = 1;
    public final StyledText name = new StyledText(0xFFFFFF);
    /** Lore lines, each with its own gradient/formatting. */
    public final List<StyledText> lore = new ArrayList<>();
    public boolean unbreakable, glint;
    public final List<AttrMod> attrs = new ArrayList<>();
    /** enchant id without namespace -> level */
    public final Map<String, Integer> enchants = new LinkedHashMap<>();

    /** Snapshot of everything except the target selector (used by presets). */
    public JsonObject toJson() {
        JsonObject o = new JsonObject();
        o.addProperty("itemId", itemId);
        o.addProperty("count", count);
        o.add("name", name.toJson());
        JsonArray ls = new JsonArray();
        for (StyledText l : lore) ls.add(l.toJson());
        o.add("lore", ls);
        o.addProperty("unbreakable", unbreakable);
        o.addProperty("glint", glint);
        JsonObject en = new JsonObject();
        for (Map.Entry<String, Integer> e : enchants.entrySet()) en.addProperty(e.getKey(), e.getValue());
        o.add("enchants", en);
        JsonArray at = new JsonArray();
        for (AttrMod m : attrs) at.add(m.toJson());
        o.add("attrs", at);
        return o;
    }

    public void loadFrom(JsonObject o) {
        itemId = o.has("itemId") ? o.get("itemId").getAsString() : "minecraft:diamond_sword";
        count = o.has("count") ? o.get("count").getAsInt() : 1;
        name.loadFrom(o.has("name") ? o.getAsJsonObject("name") : null, 0xFFFFFF);
        lore.clear();
        if (o.has("lore")) {
            for (JsonElement e : o.getAsJsonArray("lore")) {
                StyledText s = new StyledText(0xAAAAAA);
                s.loadFrom(e.getAsJsonObject(), 0xAAAAAA);
                lore.add(s);
            }
        }
        unbreakable = o.has("unbreakable") && o.get("unbreakable").getAsBoolean();
        glint = o.has("glint") && o.get("glint").getAsBoolean();
        enchants.clear();
        if (o.has("enchants")) {
            for (Map.Entry<String, JsonElement> e : o.getAsJsonObject("enchants").entrySet()) {
                enchants.put(e.getKey(), e.getValue().getAsInt());
            }
        }
        attrs.clear();
        if (o.has("attrs")) {
            for (JsonElement e : o.getAsJsonArray("attrs")) attrs.add(AttrMod.fromJson(e.getAsJsonObject()));
        }
    }

    /** Lore without trailing blank lines (blank lines in the middle are kept as spacers). */
    public List<StyledText> loreForOutput() {
        int last = -1;
        for (int i = 0; i < lore.size(); i++) if (!lore.get(i).isBlank()) last = i;
        return new ArrayList<>(lore.subList(0, last + 1));
    }

    /** Builds the command WITHOUT the leading slash. */
    public String build() {
        List<String> parts = new ArrayList<>();

        if (!name.isBlank()) parts.add("custom_name=" + name.toSnbt());

        List<StyledText> ls = loreForOutput();
        if (!ls.isEmpty()) {
            List<String> comps = new ArrayList<>();
            for (StyledText l : ls) comps.add(l.toSnbt());
            parts.add("lore=[" + String.join(",", comps) + "]");
        }

        if (!enchants.isEmpty()) {
            List<String> es = new ArrayList<>();
            for (Map.Entry<String, Integer> e : enchants.entrySet()) {
                es.add("\"minecraft:" + e.getKey() + "\":" + e.getValue());
            }
            parts.add("enchantments={" + String.join(",", es) + "}");
        }

        if (!attrs.isEmpty()) {
            List<String> as = new ArrayList<>();
            for (int i = 0; i < attrs.size(); i++) {
                AttrMod m = attrs.get(i);
                as.add("{type:\"minecraft:" + m.attribute + "\",id:\"commandsmith:mod" + i + "\",amount:"
                    + m.amountText() + "d,operation:\"" + m.operation + "\",slot:\"" + m.slot + "\"}");
            }
            parts.add("attribute_modifiers=[" + String.join(",", as) + "]");
        }

        if (unbreakable) parts.add("unbreakable={}");
        if (glint) parts.add("enchantment_glint_override=true");

        String tgt = target == null || target.isBlank() ? "@s" : target.trim();
        StringBuilder sb = new StringBuilder("give ").append(tgt).append(' ').append(itemId);
        if (!parts.isEmpty()) sb.append('[').append(String.join(",", parts)).append(']');
        if (count > 1) sb.append(' ').append(count);
        return sb.toString();
    }
}
