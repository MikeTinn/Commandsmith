package dev.commandsmith.data;

import java.util.List;
import java.util.Set;

public final class Enchants {
    private static final Set<String> ARMOR = Set.of("helmet", "chestplate", "leggings", "boots");

    public record Ench(String id, String name, int max, Set<String> groups) {
        public boolean appliesTo(String group) {
            return groups.contains("any") || groups.contains(group)
                || (groups.contains("armor") && ARMOR.contains(group));
        }
    }

    private static Ench e(String id, String name, int max, String groups) {
        return new Ench(id, name, max, Set.of(groups.split(" ")));
    }

    public static final List<Ench> ALL = List.of(
        e("sharpness", "Sharpness", 5, "sword axe"),
        e("smite", "Smite", 5, "sword axe mace"),
        e("bane_of_arthropods", "Bane of Arthropods", 5, "sword axe mace"),
        e("knockback", "Knockback", 2, "sword"),
        e("fire_aspect", "Fire Aspect", 2, "sword mace"),
        e("looting", "Looting", 3, "sword"),
        e("sweeping_edge", "Sweeping Edge", 3, "sword"),
        e("efficiency", "Efficiency", 5, "pickaxe axe shovel hoe shears"),
        e("silk_touch", "Silk Touch", 1, "pickaxe axe shovel hoe shears"),
        e("fortune", "Fortune", 3, "pickaxe axe shovel hoe"),
        e("protection", "Protection", 4, "armor"),
        e("fire_protection", "Fire Protection", 4, "armor"),
        e("blast_protection", "Blast Protection", 4, "armor"),
        e("projectile_protection", "Projectile Protection", 4, "armor"),
        e("thorns", "Thorns", 3, "armor"),
        e("respiration", "Respiration", 3, "helmet"),
        e("aqua_affinity", "Aqua Affinity", 1, "helmet"),
        e("feather_falling", "Feather Falling", 4, "boots"),
        e("depth_strider", "Depth Strider", 3, "boots"),
        e("frost_walker", "Frost Walker", 2, "boots"),
        e("soul_speed", "Soul Speed", 3, "boots"),
        e("swift_sneak", "Swift Sneak", 3, "leggings"),
        e("power", "Power", 5, "bow"),
        e("punch", "Punch", 2, "bow"),
        e("flame", "Flame", 1, "bow"),
        e("infinity", "Infinity", 1, "bow"),
        e("multishot", "Multishot", 1, "crossbow"),
        e("piercing", "Piercing", 4, "crossbow"),
        e("quick_charge", "Quick Charge", 3, "crossbow"),
        e("impaling", "Impaling", 5, "trident"),
        e("riptide", "Riptide", 3, "trident"),
        e("loyalty", "Loyalty", 3, "trident"),
        e("channeling", "Channeling", 1, "trident"),
        e("density", "Density", 5, "mace"),
        e("breach", "Breach", 4, "mace"),
        e("wind_burst", "Wind Burst", 3, "mace"),
        e("lunge", "Lunge", 3, "spear"),
        e("luck_of_the_sea", "Luck of the Sea", 3, "fishing_rod"),
        e("lure", "Lure", 3, "fishing_rod"),
        e("unbreaking", "Unbreaking", 3, "any"),
        e("mending", "Mending", 1, "any"),
        e("binding_curse", "Curse of Binding", 1, "armor elytra"),
        e("vanishing_curse", "Curse of Vanishing", 1, "any")
    );

    public static Ench byId(String id) {
        for (Ench en : ALL) if (en.id().equals(id)) return en;
        return null;
    }

    private static final String[] ROMAN = {"", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"};

    public static String roman(int n) {
        return n >= 1 && n <= 10 ? ROMAN[n] : String.valueOf(n);
    }

    private Enchants() {}
}
