package dev.commandsmith.data;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.List;

public final class ItemCatalog {
    public record Entry(Item item, String id, String path, String display, String group, String category, ItemStack stack) {}

    private static List<Entry> all;

    public static synchronized List<Entry> all() {
        if (all == null) {
            List<Entry> out = new ArrayList<>();
            for (Item item : BuiltInRegistries.ITEM) {
                String id = BuiltInRegistries.ITEM.getKey(item).toString();
                String path = id.substring(id.indexOf(':') + 1);
                if (path.equals("air")) continue;
                ItemStack stack = new ItemStack(item);
                String group = groupOf(path);
                out.add(new Entry(item, id, path, stack.getHoverName().getString(), group, categoryOf(group), stack));
            }
            all = out;
        }
        return all;
    }

    private static java.util.Map<String, Entry> index;

    public static synchronized Entry byId(String id) {
        List<Entry> list = all();
        if (index == null) {
            index = new java.util.HashMap<>();
            for (Entry e : list) index.put(e.id(), e);
        }
        return index.get(id);
    }

    static String groupOf(String p) {
        if (p.endsWith("_sword")) return "sword";
        if (p.endsWith("_pickaxe")) return "pickaxe";
        if (p.endsWith("_axe")) return "axe";
        if (p.endsWith("_shovel")) return "shovel";
        if (p.endsWith("_hoe")) return "hoe";
        if (p.endsWith("_helmet")) return "helmet";
        if (p.endsWith("_chestplate")) return "chestplate";
        if (p.endsWith("_leggings")) return "leggings";
        if (p.endsWith("_boots")) return "boots";
        if (p.endsWith("_spear")) return "spear";
        switch (p) {
            case "bow": case "crossbow": case "trident": case "mace":
            case "fishing_rod": case "shears": case "elytra": case "shield":
                return p;
            default:
                return "other";
        }
    }

    static String categoryOf(String group) {
        switch (group) {
            case "helmet": case "chestplate": case "leggings": case "boots": case "elytra":
                return "Armor";
            case "pickaxe": case "axe": case "shovel": case "hoe": case "shears": case "fishing_rod":
                return "Tools";
            case "sword": case "bow": case "crossbow": case "trident": case "mace": case "spear": case "shield":
                return "Weapons";
            default:
                return "Other";
        }
    }

    private ItemCatalog() {}
}
