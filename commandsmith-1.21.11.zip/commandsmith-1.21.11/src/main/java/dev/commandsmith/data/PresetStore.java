package dev.commandsmith.data;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/** Presets = "shulker box" folders that hold saved item configurations. */
public final class PresetStore {
    private static final Logger LOG = LoggerFactory.getLogger("commandsmith");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public static final String[] COLORS = {
        "default", "white", "orange", "magenta", "light_blue", "yellow", "lime", "pink", "gray",
        "light_gray", "cyan", "purple", "blue", "brown", "green", "red", "black"
    };

    public static final class Preset {
        public String id = UUID.randomUUID().toString();
        public String name = "New preset";
        public String color = "default";
        /** Each item is a CommandBuilder.toJson() snapshot. Compare by identity (==). */
        public final List<JsonObject> items = new ArrayList<>();
    }

    public static final List<Preset> PRESETS = new ArrayList<>();
    public static String activeId;

    private PresetStore() {}

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("commandsmith-presets.json");
    }

    public static String shulkerId(String color) {
        return "default".equals(color) ? "minecraft:shulker_box" : "minecraft:" + color + "_shulker_box";
    }

    public static Preset find(String id) {
        if (id == null) return null;
        for (Preset p : PRESETS) if (p.id.equals(id)) return p;
        return null;
    }

    public static Preset active() {
        return find(activeId);
    }

    public static Preset create() {
        Preset p = new Preset();
        p.name = "Preset " + (PRESETS.size() + 1);
        PRESETS.add(p);
        activeId = p.id;
        save();
        return p;
    }

    public static Preset owner(JsonObject item) {
        for (Preset p : PRESETS) for (JsonObject i : p.items) if (i == item) return p;
        return null;
    }

    public static boolean replace(JsonObject oldItem, JsonObject newItem) {
        for (Preset p : PRESETS) {
            for (int i = 0; i < p.items.size(); i++) {
                if (p.items.get(i) == oldItem) {
                    p.items.set(i, newItem);
                    return true;
                }
            }
        }
        return false;
    }

    public static int indexOf(List<JsonObject> list, JsonObject item) {
        for (int i = 0; i < list.size(); i++) if (list.get(i) == item) return i;
        return -1;
    }

    public static void load() {
        PRESETS.clear();
        try {
            Path f = file();
            if (!Files.exists(f)) return;
            JsonObject root = JsonParser.parseString(Files.readString(f)).getAsJsonObject();
            if (root.has("active") && !root.get("active").isJsonNull()) activeId = root.get("active").getAsString();
            if (root.has("presets")) {
                for (JsonElement el : root.getAsJsonArray("presets")) {
                    JsonObject po = el.getAsJsonObject();
                    Preset p = new Preset();
                    if (po.has("id")) p.id = po.get("id").getAsString();
                    if (po.has("name")) p.name = po.get("name").getAsString();
                    if (po.has("color")) p.color = po.get("color").getAsString();
                    if (po.has("items")) {
                        for (JsonElement ie : po.getAsJsonArray("items")) p.items.add(ie.getAsJsonObject());
                    }
                    PRESETS.add(p);
                }
            }
        } catch (Exception e) {
            LOG.warn("Could not read presets", e);
        }
    }

    public static void save() {
        try {
            JsonObject root = new JsonObject();
            if (activeId != null) root.addProperty("active", activeId);
            JsonArray arr = new JsonArray();
            for (Preset p : PRESETS) {
                JsonObject po = new JsonObject();
                po.addProperty("id", p.id);
                po.addProperty("name", p.name);
                po.addProperty("color", p.color);
                JsonArray items = new JsonArray();
                for (JsonObject i : p.items) items.add(i);
                po.add("items", items);
                arr.add(po);
            }
            root.add("presets", arr);
            Files.writeString(file(), GSON.toJson(root));
        } catch (Exception e) {
            LOG.warn("Could not save presets", e);
        }
    }
}
