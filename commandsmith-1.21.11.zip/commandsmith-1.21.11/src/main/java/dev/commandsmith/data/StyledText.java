package dev.commandsmith.data;

import java.util.ArrayList;
import java.util.List;

/** Text with a multi-stop RGB gradient (Birdflop style) plus formatting flags. */
public final class StyledText {
    public String text = "";
    /** Gradient stops as 0xRRGGBB. One stop = solid colour. */
    public final List<Integer> stops = new ArrayList<>();
    public boolean bold, italic, underline, strike, obfuscated;

    public StyledText(int color) {
        stops.add(color & 0xFFFFFF);
    }

    public StyledText copy() {
        StyledText c = new StyledText(stops.get(0));
        c.text = text;
        c.copyStyleFrom(this);
        return c;
    }

    public void copyStyleFrom(StyledText o) {
        stops.clear();
        stops.addAll(o.stops);
        bold = o.bold;
        italic = o.italic;
        underline = o.underline;
        strike = o.strike;
        obfuscated = o.obfuscated;
    }

    public boolean isBlank() {
        return text.isBlank();
    }

    public List<String> chars() {
        List<String> out = new ArrayList<>();
        text.codePoints().forEach(cp -> out.add(new String(Character.toChars(cp))));
        return out;
    }

    public static int lerp(int a, int b, float f) {
        int ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255;
        int br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255;
        int r = Math.round(ar + (br - ar) * f);
        int g = Math.round(ag + (bg - ag) * f);
        int bl = Math.round(ab + (bb - ab) * f);
        return (r << 16) | (g << 8) | bl;
    }

    /** Colour of character i out of n, spread evenly across all stops. */
    public int colorAt(int i, int n) {
        int s = stops.size();
        if (s == 1 || n <= 1) return stops.get(0);
        float pos = (float) i / (n - 1) * (s - 1);
        int k = Math.min((int) pos, s - 2);
        return lerp(stops.get(k), stops.get(k + 1), pos - k);
    }

    private static String hex(int rgb) {
        return String.format("#%06x", rgb & 0xFFFFFF);
    }

    private static String esc(String s) {
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    /** SNBT text component for custom_name / lore lines. */
    public String toSnbt() {
        List<String> chars = chars();
        int n = chars.size();

        StringBuilder style = new StringBuilder();
        if (bold) style.append(",bold:true");
        if (underline) style.append(",underlined:true");
        if (strike) style.append(",strikethrough:true");
        if (obfuscated) style.append(",obfuscated:true");
        style.append(",italic:").append(italic);

        // merge neighbouring characters that share a colour
        List<String> runText = new ArrayList<>();
        List<String> runColor = new ArrayList<>();
        StringBuilder cur = null;
        String curColor = null;
        for (int i = 0; i < n; i++) {
            String col = hex(colorAt(i, n));
            if (!col.equals(curColor)) {
                if (cur != null) { runText.add(cur.toString()); runColor.add(curColor); }
                cur = new StringBuilder();
                curColor = col;
            }
            cur.append(chars.get(i));
        }
        if (cur != null) { runText.add(cur.toString()); runColor.add(curColor); }

        if (runText.size() <= 1) {
            String col = runColor.isEmpty() ? hex(stops.get(0)) : runColor.get(0);
            return "{text:\"" + esc(text) + "\",color:\"" + col + "\"" + style + "}";
        }
        List<String> extra = new ArrayList<>();
        for (int i = 0; i < runText.size(); i++) {
            extra.add("{text:\"" + esc(runText.get(i)) + "\",color:\"" + runColor.get(i) + "\"}");
        }
        return "{text:\"\"" + style + ",extra:[" + String.join(",", extra) + "]}";
    }
}
