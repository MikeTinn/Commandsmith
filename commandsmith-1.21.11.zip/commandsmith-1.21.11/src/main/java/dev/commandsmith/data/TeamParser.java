package dev.commandsmith.data;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Pulls player names out of a "/team info" style chat message (owner / admin / members). */
public final class TeamParser {
    public enum Role {
        OWNER("OWNER"), ADMIN("ADMIN"), MEMBER("MEMBER"), OTHER("");
        public final String label;
        Role(String label) { this.label = label; }
    }

    public static final class Member {
        public final String name;
        public final Role role;
        public boolean on = true;

        public Member(String name, Role role) {
            this.name = name;
            this.role = role;
        }
    }

    private static final Pattern TOKEN = Pattern.compile("[A-Za-z0-9_]+");
    private static final Set<String> OWNER = Set.of("owner", "owners", "leader", "leaders", "founder", "founders");
    private static final Set<String> ADMIN = Set.of("admin", "admins", "administrator", "administrators",
        "moderator", "moderators", "officer", "officers", "mod", "mods");
    private static final Set<String> MEMBER = Set.of("member", "members");
    private static final Set<String> STOP = Set.of("team", "teams", "info", "information", "name", "tag", "online",
        "offline", "none", "size", "players", "player", "created", "date", "description", "desc", "motd", "home",
        "bank", "balance", "level", "status", "kills", "deaths", "list", "page", "the", "and", "you", "your",
        "are", "not", "for", "has", "have", "with", "from", "total", "count");

    private TeamParser() {}

    private static Role roleOf(String low) {
        if (OWNER.contains(low)) return Role.OWNER;
        if (ADMIN.contains(low)) return Role.ADMIN;
        if (MEMBER.contains(low)) return Role.MEMBER;
        return null;
    }

    private static boolean isName(String t) {
        if (t.length() < 3 || t.length() > 16) return false;
        if (t.chars().allMatch(Character::isDigit)) return false;
        return !STOP.contains(t.toLowerCase(Locale.ROOT));
    }

    public static boolean hasRoleKeyword(String line) {
        Matcher m = TOKEN.matcher(line);
        while (m.find()) if (roleOf(m.group().toLowerCase(Locale.ROOT)) != null) return true;
        return false;
    }

    private static boolean hasWord(String line, Set<String> words) {
        Matcher m = TOKEN.matcher(line);
        while (m.find()) if (words.contains(m.group().toLowerCase(Locale.ROOT))) return true;
        return false;
    }

    /** True when the last meaningful word of the line is a role keyword (names follow on the next line). */
    private static boolean endsWithRoleKeyword(String line) {
        boolean last = false;
        Matcher m = TOKEN.matcher(line);
        while (m.find()) {
            String t = m.group();
            if (roleOf(t.toLowerCase(Locale.ROOT)) != null) last = true;
            else if (isName(t)) last = false;
        }
        return last;
    }

    /** Guesses which chat lines belong to the latest team info block. */
    public static boolean[] autoSelect(List<String> lines) {
        boolean[] sel = new boolean[lines.size()];
        int start = -1;
        for (int i = lines.size() - 1; i >= 0 && start < 0; i--) if (hasWord(lines.get(i), OWNER)) start = i;
        for (int i = lines.size() - 1; i >= 0 && start < 0; i--) if (hasWord(lines.get(i), MEMBER)) start = i;
        if (start < 0) return sel;
        int end = start;
        for (int j = start + 1; j < lines.size() && j <= start + 8; j++) {
            if (hasRoleKeyword(lines.get(j)) || endsWithRoleKeyword(lines.get(j - 1))) end = j; else break;
        }
        for (int k = start; k <= end; k++) sel[k] = true;
        return sel;
    }

    public static List<Member> parse(List<String> lines) {
        Role role = Role.OTHER;
        Map<String, Member> out = new LinkedHashMap<>();
        for (String line : lines) {
            Matcher m = TOKEN.matcher(line);
            while (m.find()) {
                String t = m.group();
                Role r = roleOf(t.toLowerCase(Locale.ROOT));
                if (r != null) { role = r; continue; }
                if (!isName(t)) continue;
                out.putIfAbsent(t.toLowerCase(Locale.ROOT), new Member(t, role));
            }
        }
        return new ArrayList<>(out.values());
    }
}
