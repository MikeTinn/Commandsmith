package dev.commandsmith.gui;

import java.util.HashMap;
import java.util.Map;

/** Tiny animation helpers: eased progress, colour mixing, smoothed hover values. */
final class Anim {
    private static long last = System.nanoTime();
    private static float dt = 0.016f;

    private Anim() {}

    /** Call once per rendered frame (from a screen's render entry point). */
    static void frame() {
        long n = System.nanoTime();
        dt = Math.min(0.05f, (n - last) / 1_000_000_000f);
        last = n;
    }

    static float clamp01(float v) { return Math.max(0f, Math.min(1f, v)); }

    /** Ease-out cubic. */
    static float ease(float t) {
        float u = 1f - clamp01(t);
        return 1f - u * u * u;
    }

    static float progress(long startMillis, int durationMs) {
        return clamp01((System.currentTimeMillis() - startMillis) / (float) durationMs);
    }

    private static int lerp(int x, int y, float t) { return Math.round(x + (y - x) * t); }

    /** Mix two ARGB colours. */
    static int mix(int a, int b, float t) {
        t = clamp01(t);
        return (lerp(a >>> 24, b >>> 24, t) << 24)
            | (lerp((a >> 16) & 255, (b >> 16) & 255, t) << 16)
            | (lerp((a >> 8) & 255, (b >> 8) & 255, t) << 8)
            | lerp(a & 255, b & 255, t);
    }

    /** Smoothed 0..1 hover amount per widget key. */
    static final class Hover {
        private final Map<Integer, Float> map = new HashMap<>();

        float t(int key, boolean on) {
            float v = map.getOrDefault(key, 0f);
            float target = on ? 1f : 0f;
            v += (target - v) * Math.min(1f, dt * 16f);
            if (Math.abs(target - v) < 0.01f) v = target;
            map.put(key, v);
            return v;
        }
    }
}
