package dev.commandsmith.gui;

import dev.commandsmith.data.AttrMod;
import dev.commandsmith.data.Attributes;
import dev.commandsmith.data.CommandBuilder;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.function.IntConsumer;

import static dev.commandsmith.gui.GeneratorScreen.*;

/** Attribute modifier editor. Opens on top of the generator, like the text editor. */
public class AttributeEditorScreen extends Screen {
    private record Hit(int x, int y, int w, int h, Runnable action) {}
    private record Zone(int x, int y, int w, int h, IntConsumer onScroll) {}

    private static final String[][] SLOTS_1 = {{"Any", "any"}, {"Hand", "hand"}, {"Main", "mainhand"}, {"Off", "offhand"}, {"Armor", "armor"}};
    private static final String[][] SLOTS_2 = {{"Head", "head"}, {"Chest", "chest"}, {"Legs", "legs"}, {"Feet", "feet"}};
    private static final String[] STEP_LABELS = {"-10", "-1", "-.1", "+.1", "+1", "+10"};
    private static final double[] STEPS = {-10, -1, -0.1, 0.1, 1, 10};
    private static final int ATTR_ROW = 13, ATTR_LIST_H = 78;

    private final GeneratorScreen parent;
    private final CommandBuilder cmd;
    private final String defaultSlot;

    private int sel;
    private boolean suppress;
    private int modScroll, attrScroll;
    private EditBox amountBox;
    private final List<Hit> hits = new ArrayList<>();
    private final List<Zone> zones = new ArrayList<>();
    private int mxPos, myPos;
    private final Anim.Hover hover = new Anim.Hover();
    private final long openAt = System.currentTimeMillis();
    private long closeAt;

    private int ox, oy, ow, oh, ct, cb, lx2, lw2, rx2, rw2;

    public AttributeEditorScreen(GeneratorScreen parent, CommandBuilder cmd, String defaultSlot) {
        super(Component.literal("Edit attributes"));
        this.parent = parent;
        this.cmd = cmd;
        this.defaultSlot = defaultSlot;
        this.sel = cmd.attrs.isEmpty() ? -1 : 0;
    }

    private AttrMod cur() { return cmd.attrs.get(sel); }

    // ---- setup -------------------------------------------------------------
    @Override
    protected void init() {
        parent.resize(this.width, this.height);
        ow = Math.min(470, this.width - 16);
        oh = Math.min(256, this.height - 16);
        ox = (this.width - ow) / 2;
        oy = (this.height - oh) / 2;
        ct = oy + 30;
        cb = oy + oh - 30;
        lx2 = ox + 10;
        lw2 = (ow - 30) * 46 / 100;
        rx2 = lx2 + lw2 + 10;
        rw2 = ox + ow - 10 - rx2;

        amountBox = new EditBox(this.font, rx2 + 4, ct + 107, 72, 10, Component.literal("Amount"));
        amountBox.setBordered(false);
        amountBox.setMaxLength(9);
        amountBox.setFilter(s -> s.matches("-?\\d{0,5}(\\.\\d{0,3})?"));
        amountBox.setHint(Component.literal("amount"));
        loadAmount();
        amountBox.setResponder(this::onAmount);
        this.addWidget(amountBox);
        if (sel >= 0) { this.setFocused(amountBox); amountBox.setFocused(true); }
    }

    private static int clamp(int v, int lo, int hi) { return Math.max(lo, Math.min(hi, v)); }

    // ---- logic -------------------------------------------------------------
    private void loadAmount() {
        suppress = true;
        amountBox.setValue(sel >= 0 ? cur().amountText() : "");
        suppress = false;
    }

    private void onAmount(String s) {
        if (suppress || sel < 0) return;
        try { cur().amount = Double.parseDouble(s); } catch (NumberFormatException ignored) { }
    }

    private void step(double d) {
        if (sel < 0) return;
        cur().amount = Math.round((cur().amount + d) * 1000.0) / 1000.0;
        loadAmount();
    }

    private void scrollToAttribute() {
        if (sel < 0) return;
        int max = Math.max(0, Attributes.ALL.size() * ATTR_ROW - ATTR_LIST_H);
        attrScroll = clamp(Attributes.indexOf(cur().attribute) * ATTR_ROW - ATTR_ROW * 2, 0, max);
    }

    private void select(int i) {
        sel = i;
        loadAmount();
        scrollToAttribute();
    }

    private void addMod() {
        AttrMod m;
        if (sel >= 0) m = cur().copy();
        else { m = new AttrMod(); m.slot = defaultSlot; }
        int at = sel + 1;
        cmd.attrs.add(at, m);
        select(at);
    }

    private void delMod() {
        if (sel < 0) return;
        cmd.attrs.remove(sel);
        select(cmd.attrs.isEmpty() ? -1 : clamp(sel, 0, cmd.attrs.size() - 1));
    }

    @Override
    public void onClose() {
        if (closeAt == 0) closeAt = System.currentTimeMillis();
    }

    // ---- input -------------------------------------------------------------
    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (closeAt != 0) return true;
        if (event.button() == 0) {
            for (int i = hits.size() - 1; i >= 0; i--) {
                Hit h = hits.get(i);
                if (inside((int) event.x(), (int) event.y(), h.x, h.y, h.w, h.h)) {
                    this.setFocused(null);
                    h.action.run();
                    return true;
                }
            }
        }
        return super.mouseClicked(event, doubleClick);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        for (Zone z : zones) {
            if (inside((int) mouseX, (int) mouseY, z.x, z.y, z.w, z.h)) {
                z.onScroll.accept(scrollY > 0 ? 1 : -1);
                return true;
            }
        }
        return super.mouseScrolled(mouseX, mouseY, scrollX, scrollY);
    }

    // ---- render ------------------------------------------------------------
    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        Anim.frame();
        if (closeAt != 0 && Anim.progress(closeAt, 140) >= 1f) {
            this.minecraft.setScreen(this.parent);
        }
        hits.clear();
        zones.clear();
        mxPos = mouseX;
        myPos = mouseY;
        amountBox.visible = sel >= 0;

        float vis = Anim.ease(Anim.progress(openAt, 200)) * (closeAt == 0 ? 1f : 1f - Anim.ease(Anim.progress(closeAt, 140)));
        parent.renderUi(g, -10000, -10000, delta);
        g.fill(0, 0, this.width, this.height, ((int) (200 * vis)) << 24);
        var slide = g.pose();
        slide.pushMatrix();
        slide.translate(0f, (1f - vis) * 12f);

        g.fill(ox, oy, ox + ow, oy + oh, PANEL);
        border(g, ox, oy, ow, oh, BORDER);
        g.fill(ox, oy, ox + ow, oy + 22, PANEL2);
        g.fill(ox, oy + 22, ox + ow, oy + 23, BORDER);
        g.fill(ox, oy, ox + 3, oy + 22, ACCENT);
        g.drawString(this.font, "EDIT ATTRIBUTES", ox + 12, oy + 7, TEXT, false);
        g.drawString(this.font, "attribute modifiers", ox + 12 + this.font.width("EDIT ATTRIBUTES") + 8, oy + 7, MUTED, false);
        button(g, ox + ow - 22, oy + 2, 18, 18, "X", false, false, this::onClose);

        drawLeft(g);
        drawRight(g, delta);

        int doneW = 90;
        g.drawString(this.font, fit("Heads up: this replaces the item's default attributes.", ow - 20 - doneW - 12),
            ox + 10, oy + oh - 23, 0xFFC9A227, false);
        button(g, ox + ow - 10 - doneW, oy + oh - 10 - 18, doneW, 18, "DONE", false, true, this::onClose);
        int cover = (int) ((1f - vis) * 255f);
        if (cover > 0) g.fill(ox, oy, ox + ow, oy + oh, (cover << 24) | 0x0A0C11);
        slide.popMatrix();
    }

    private void drawLeft(GuiGraphics g) {
        label(g, "MODIFIERS  (" + cmd.attrs.size() + ")", lx2, ct);

        int listY = ct + 10, listH = 70, rowH = 14;
        g.fill(lx2, listY, lx2 + lw2, listY + listH, PANEL2);
        border(g, lx2, listY, lw2, listH, BORDER);
        int content = cmd.attrs.size() * rowH;
        int maxScroll = Math.max(0, content - listH);
        modScroll = clamp(modScroll, 0, maxScroll);
        g.enableScissor(lx2 + 1, listY + 1, lx2 + lw2 - 1, listY + listH - 1);
        if (cmd.attrs.isEmpty()) g.drawString(this.font, "None yet - press Add", lx2 + 6, listY + 6, MUTED, false);
        for (int i = 0; i < cmd.attrs.size(); i++) {
            int ry = listY + i * rowH - modScroll;
            if (ry + rowH <= listY) continue;
            if (ry >= listY + listH) break;
            AttrMod m = cmd.attrs.get(i);
            int cy1 = Math.max(ry, listY), cy2 = Math.min(ry + rowH, listY + listH);
            boolean on = i == sel;
            if (on) { g.fill(lx2 + 1, ry, lx2 + lw2 - 1, ry + rowH, ACCENT_DIM); g.fill(lx2 + 1, ry, lx2 + 3, ry + rowH, ACCENT); }
            else if (inside(mxPos, myPos, lx2, cy1, lw2, cy2 - cy1)) g.fill(lx2 + 1, ry, lx2 + lw2 - 1, ry + rowH, HOVER);
            String right = fit(m.summary() + " " + m.slot, lw2 / 2);
            int rw = this.font.width(right);
            g.drawString(this.font, fit((i + 1) + ". " + Attributes.nameOf(m.attribute), lw2 - rw - 22), lx2 + 7, ry + 3, on ? TEXT : 0xFFB4BCD0, false);
            g.drawString(this.font, right, lx2 + lw2 - rw - 6, ry + 3, on ? ENCH : MUTED, false);
            int idx = i;
            hits.add(new Hit(lx2, cy1, lw2, cy2 - cy1, () -> select(idx)));
        }
        g.disableScissor();
        if (content > listH) {
            int thumb = Math.max(12, listH * listH / content);
            int ty = listY + (int) ((long) (listH - thumb) * modScroll / (content - listH));
            g.fill(lx2 + lw2 - 3, ty, lx2 + lw2 - 1, ty + thumb, 0xFF4A5372);
        }
        zones.add(new Zone(lx2, listY, lw2, listH, d -> modScroll = clamp(modScroll - d * rowH, 0, maxScroll)));

        int bw = (lw2 - 2) / 2;
        button(g, lx2, ct + 84, bw, 14, "Add", false, false, this::addMod);
        button(g, lx2 + bw + 2, ct + 84, lw2 - bw - 2, 14, "Delete", false, false, this::delMod);

        if (sel < 0) return;
        label(g, "OPERATION", lx2, ct + 104);
        String[][] ops = {{"Add", "add_value"}, {"+% Base", "add_multiplied_base"}, {"x Total", "add_multiplied_total"}};
        int ow3 = (lw2 - 4) / 3;
        for (int i = 0; i < 3; i++) {
            String id = ops[i][1];
            button(g, lx2 + i * (ow3 + 2), ct + 114, ow3, 14, ops[i][0], cur().operation.equals(id), false, () -> cur().operation = id);
        }
        String desc;
        switch (cur().operation) {
            case "add_multiplied_base": desc = "Adds amount x the base value (0.5 = +50% of base)."; break;
            case "add_multiplied_total": desc = "Multiplies the final value (0.5 = x1.5 total)."; break;
            default: desc = "Adds the amount directly (5 = +5)."; break;
        }
        int dy = ct + 134;
        for (String line : wrapWords(desc, lw2)) {
            g.drawString(this.font, line, lx2, dy, MUTED, false);
            dy += 10;
        }
    }

    private void drawRight(GuiGraphics g, float delta) {
        if (sel < 0) {
            g.drawString(this.font, "Press Add to create a modifier.", rx2, ct + 4, MUTED, false);
            return;
        }
        AttrMod m = cur();

        label(g, "ATTRIBUTE", rx2, ct);
        int listY = ct + 10;
        g.fill(rx2, listY, rx2 + rw2, listY + ATTR_LIST_H, PANEL2);
        border(g, rx2, listY, rw2, ATTR_LIST_H, BORDER);
        int content = Attributes.ALL.size() * ATTR_ROW;
        int maxScroll = Math.max(0, content - ATTR_LIST_H);
        attrScroll = clamp(attrScroll, 0, maxScroll);
        g.enableScissor(rx2 + 1, listY + 1, rx2 + rw2 - 1, listY + ATTR_LIST_H - 1);
        for (int i = 0; i < Attributes.ALL.size(); i++) {
            int ry = listY + i * ATTR_ROW - attrScroll;
            if (ry + ATTR_ROW <= listY) continue;
            if (ry >= listY + ATTR_LIST_H) break;
            Attributes.Attr a = Attributes.ALL.get(i);
            int cy1 = Math.max(ry, listY), cy2 = Math.min(ry + ATTR_ROW, listY + ATTR_LIST_H);
            boolean on = a.id().equals(m.attribute);
            if (on) { g.fill(rx2 + 1, ry, rx2 + rw2 - 1, ry + ATTR_ROW, ACCENT_DIM); g.fill(rx2 + 1, ry, rx2 + 3, ry + ATTR_ROW, ACCENT); }
            else if (inside(mxPos, myPos, rx2, cy1, rw2, cy2 - cy1)) g.fill(rx2 + 1, ry, rx2 + rw2 - 1, ry + ATTR_ROW, HOVER);
            g.drawString(this.font, fit(a.name(), rw2 - 16), rx2 + 7, ry + 3, on ? TEXT : 0xFFB4BCD0, false);
            hits.add(new Hit(rx2, cy1, rw2, cy2 - cy1, () -> m.attribute = a.id()));
        }
        g.disableScissor();
        if (content > ATTR_LIST_H) {
            int thumb = Math.max(12, ATTR_LIST_H * ATTR_LIST_H / content);
            int ty = listY + (int) ((long) (ATTR_LIST_H - thumb) * attrScroll / (content - ATTR_LIST_H));
            g.fill(rx2 + rw2 - 3, ty, rx2 + rw2 - 1, ty + thumb, 0xFF4A5372);
        }
        zones.add(new Zone(rx2, listY, rw2, ATTR_LIST_H, d -> attrScroll = clamp(attrScroll - d * ATTR_ROW * 2, 0, maxScroll)));

        // amount: typed, with quick steps
        label(g, "AMOUNT  (type it, or use the steps)", rx2, ct + 94);
        fieldBg(g, rx2, ct + 104, 80, 14, amountBox);
        amountBox.render(g, mxPos, myPos, delta);
        g.drawString(this.font, "= " + m.summary(), rx2 + 90, ct + 107, ENCH, false);
        int sw = (rw2 - 5 * 2) / 6;
        for (int i = 0; i < STEPS.length; i++) {
            double d = STEPS[i];
            button(g, rx2 + i * (sw + 2), ct + 122, sw, 14, STEP_LABELS[i], false, false, () -> step(d));
        }

        // slot
        label(g, "SLOT  " + m.slot, rx2, ct + 142);
        int s1 = (rw2 - (SLOTS_1.length - 1) * 2) / SLOTS_1.length;
        for (int i = 0; i < SLOTS_1.length; i++) {
            String id = SLOTS_1[i][1];
            button(g, rx2 + i * (s1 + 2), ct + 152, s1, 14, SLOTS_1[i][0], m.slot.equals(id), false, () -> m.slot = id);
        }
        int s2 = (rw2 - (SLOTS_2.length - 1) * 2) / SLOTS_2.length;
        for (int i = 0; i < SLOTS_2.length; i++) {
            String id = SLOTS_2[i][1];
            button(g, rx2 + i * (s2 + 2), ct + 169, s2, 14, SLOTS_2[i][0], m.slot.equals(id), false, () -> m.slot = id);
        }
    }

    // ---- helpers -------------------------------------------------------------
    private void button(GuiGraphics g, int x, int y, int w, int h, String label, boolean active, boolean primary, Runnable r) {
        boolean hov = inside(mxPos, myPos, x, y, w, h);
        float ht = hover.t(x * 31 + y * 17 + w, hov);
        int bg = primary ? Anim.mix(ACCENT, 0xFF8279FF, ht) : active ? Anim.mix(ACCENT_DIM, 0xFF38337F, ht) : Anim.mix(PANEL2, HOVER, ht);
        int bd = primary || active ? ACCENT : Anim.mix(BORDER, 0xFF4A5372, ht);
        g.fill(x, y, x + w, y + h, bg);
        border(g, x, y, w, h, bd);
        String l = fit(label, w - 4);
        g.drawString(this.font, l, x + (w - this.font.width(l)) / 2, y + (h - 8) / 2 + 1,
            primary ? 0xFFFFFFFF : active ? TEXT : 0xFFB4BCD0, false);
        hits.add(new Hit(x, y, w, h, r));
    }

    private void fieldBg(GuiGraphics g, int x, int y, int w, int h, EditBox box) {
        g.fill(x, y, x + w, y + h, PANEL2);
        border(g, x, y, w, h, box != null && box.isFocused() ? ACCENT : BORDER);
    }

    private void border(GuiGraphics g, int x, int y, int w, int h, int c) {
        g.fill(x, y, x + w, y + 1, c);
        g.fill(x, y + h - 1, x + w, y + h, c);
        g.fill(x, y, x + 1, y + h, c);
        g.fill(x + w - 1, y, x + w, y + h, c);
    }

    private void label(GuiGraphics g, String s, int x, int y) {
        g.drawString(this.font, s, x, y, MUTED, false);
    }

    private static boolean inside(int px, int py, int x, int y, int w, int h) {
        return px >= x && px < x + w && py >= y && py < y + h;
    }

    private String fit(String s, int maxW) {
        if (maxW <= 0) return "";
        if (this.font.width(s) <= maxW) return s;
        while (!s.isEmpty() && this.font.width(s + "..") > maxW) s = s.substring(0, s.length() - 1);
        return s + "..";
    }

    private List<String> wrapWords(String s, int maxW) {
        List<String> out = new ArrayList<>();
        StringBuilder line = new StringBuilder();
        for (String w : s.split(" ")) {
            String test = line.length() == 0 ? w : line + " " + w;
            if (this.font.width(test) > maxW && line.length() > 0) {
                out.add(line.toString());
                line.setLength(0);
                line.append(w);
            } else {
                line.setLength(0);
                line.append(test);
            }
        }
        if (line.length() > 0) out.add(line.toString());
        return out;
    }
}
