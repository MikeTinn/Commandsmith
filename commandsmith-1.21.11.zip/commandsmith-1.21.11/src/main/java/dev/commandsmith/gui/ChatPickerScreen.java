package dev.commandsmith.gui;

import dev.commandsmith.data.TeamParser;
import dev.commandsmith.data.TeamParser.Member;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.function.IntConsumer;

import static dev.commandsmith.gui.GeneratorScreen.*;

/** Pick the chat lines that hold the team info, by hand. Opens on top of the Ranks tab. */
public class ChatPickerScreen extends Screen {
    private record Hit(int x, int y, int w, int h, Runnable action) {}
    private record Zone(int x, int y, int w, int h, IntConsumer onScroll) {}

    private final RanksScreen parent;
    private final List<String> lines;
    private final boolean[] sel;
    private final boolean[] auto;
    private int scroll = Integer.MAX_VALUE / 2; // start at the newest lines
    private int found;

    private final List<Hit> hits = new ArrayList<>();
    private final List<Zone> zones = new ArrayList<>();
    private int mxPos, myPos;
    private final Anim.Hover hover = new Anim.Hover();
    private final long openAt = System.currentTimeMillis();
    private long closeAt;

    private int ox, oy, ow, oh, ct, cb;

    public ChatPickerScreen(RanksScreen parent, List<String> lines, boolean[] auto) {
        super(Component.literal("Pick chat lines"));
        this.parent = parent;
        this.lines = lines;
        this.auto = auto;
        this.sel = auto.clone();
        refreshCount();
    }

    @Override
    protected void init() {
        parent.resize(this.minecraft, this.width, this.height);
        ow = Math.min(470, this.width - 16);
        oh = Math.min(256, this.height - 16);
        ox = (this.width - ow) / 2;
        oy = (this.height - oh) / 2;
        ct = oy + 30;
        cb = oy + oh - 30;
    }

    private static int clamp(int v, int lo, int hi) { return Math.max(lo, Math.min(hi, v)); }

    private List<String> chosen() {
        List<String> out = new ArrayList<>();
        for (int i = 0; i < lines.size(); i++) if (sel[i]) out.add(lines.get(i));
        return out;
    }

    private void refreshCount() {
        found = TeamParser.parse(chosen()).size();
    }

    private void use() {
        List<Member> ms = TeamParser.parse(chosen());
        if (ms.isEmpty()) return;
        parent.setMembers(ms);
        parent.say("Found " + ms.size() + " players");
        onClose();
    }

    @Override
    public void onClose() {
        if (closeAt == 0) closeAt = System.currentTimeMillis();
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (closeAt != 0) return true;
        if (event.button() == 0) {
            for (int i = hits.size() - 1; i >= 0; i--) {
                Hit h = hits.get(i);
                if (inside((int) event.x(), (int) event.y(), h.x, h.y, h.w, h.h)) {
                    h.action.run();
                    return true;
                }
            }
        }
        return super.mouseClicked(event, doubleClick);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        for (Zone z : zones) {
            if (inside((int) mouseX, (int) mouseY, z.x, z.y, z.w, z.h)) {
                z.onScroll.accept(scrollY > 0 ? 1 : -1);
                return true;
            }
        }
        return super.mouseScrolled(mouseX, mouseY, scrollX, scrollY);
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        Anim.frame();
        if (closeAt != 0 && Anim.progress(closeAt, 140) >= 1f) {
            this.minecraft.setScreen(this.parent);
        }
        hits.clear();
        zones.clear();
        mxPos = mouseX;
        myPos = mouseY;

        float vis = Anim.ease(Anim.progress(openAt, 200)) * (closeAt == 0 ? 1f : 1f - Anim.ease(Anim.progress(closeAt, 140)));
        parent.renderUi(g, -10000, -10000, delta);
        g.fill(0, 0, this.width, this.height, ((int) (200 * vis)) << 24);
        var slide = g.pose();
        slide.pushMatrix();
        slide.translate(0f, (1f - vis) * 12f);

        g.fill(ox, oy, ox + ow, oy + oh, PANEL);
        border(g, ox, oy, ow, oh, BORDER);
        g.fill(ox, oy, ox + ow, oy + 22, PANEL2);
        g.fill(ox, oy + 22, ox + ow, oy + 23, BORDER);
        g.fill(ox, oy, ox + 3, oy + 22, ACCENT);
        g.drawString(this.font, "PICK CHAT LINES", ox + 12, oy + 7, TEXT, false);
        g.drawString(this.font, "click the lines that hold your team info", ox + 12 + this.font.width("PICK CHAT LINES") + 8, oy + 7, MUTED, false);
        button(g, ox + ow - 22, oy + 2, 18, 18, "X", false, false, this::onClose);

        drawList(g);

        String info = lines.isEmpty() ? "No chat lines found" : found + " players found in the selected lines";
        g.drawString(this.font, fit(info, ow - 20 - 230), ox + 10, oy + oh - 23, MUTED, false);
        int by = oy + oh - 10 - 18;
        button(g, ox + ow - 10 - 230, by, 54, 18, "None", false, false, () -> { java.util.Arrays.fill(sel, false); refreshCount(); });
        button(g, ox + ow - 10 - 172, by, 54, 18, "Auto", false, false, () -> { System.arraycopy(auto, 0, sel, 0, sel.length); refreshCount(); });
        if (found > 0) button(g, ox + ow - 10 - 114, by, 114, 18, "USE SELECTED", false, true, this::use);
        else {
            g.fill(ox + ow - 10 - 114, by, ox + ow - 10, by + 18, PANEL);
            border(g, ox + ow - 10 - 114, by, 114, 18, BORDER);
            g.drawString(this.font, "USE SELECTED", ox + ow - 10 - 114 + (114 - this.font.width("USE SELECTED")) / 2, by + 5, 0xFF4B5268, false);
        }

        int cover = (int) ((1f - vis) * 255f);
        if (cover > 0) g.fill(ox, oy, ox + ow, oy + oh, (cover << 24) | 0x0A0C11);
        slide.popMatrix();
    }

    private void drawList(GuiGraphics g) {
        int lx = ox + 10, lw = ow - 20, ly = ct, lh = cb - ct, rowH = 13;
        g.fill(lx, ly, lx + lw, ly + lh, PANEL2);
        border(g, lx, ly, lw, lh, BORDER);
        int content = lines.size() * rowH;
        int maxScroll = Math.max(0, content - lh);
        scroll = clamp(scroll, 0, maxScroll);
        g.enableScissor(lx + 1, ly + 1, lx + lw - 1, ly + lh - 1);
        if (lines.isEmpty()) g.drawString(this.font, "Nothing in chat yet. Run /team info first.", lx + 8, ly + 8, MUTED, false);
        for (int i = 0; i < lines.size(); i++) {
            int ry = ly + i * rowH - scroll;
            if (ry + rowH <= ly) continue;
            if (ry >= ly + lh) break;
            int cy1 = Math.max(ry, ly), cy2 = Math.min(ry + rowH, ly + lh);
            boolean hov = inside(mxPos, myPos, lx, cy1, lw, cy2 - cy1);
            float t = hover.t(2000 + i, hov);
            if (sel[i]) { g.fill(lx + 1, ry, lx + lw - 1, ry + rowH, ACCENT_DIM); g.fill(lx + 1, ry, lx + 3, ry + rowH, ACCENT); }
            else if (t > 0f) g.fill(lx + 1, ry, lx + lw - 1, ry + rowH, Anim.mix(PANEL2, HOVER, t));
            g.fill(lx + 8, ry + 3, lx + 15, ry + 10, PANEL);
            border(g, lx + 8, ry + 3, 7, 7, sel[i] ? ACCENT : BORDER);
            if (sel[i]) g.fill(lx + 10, ry + 5, lx + 13, ry + 8, ACCENT);
            g.drawString(this.font, fit(lines.get(i), lw - 30), lx + 22, ry + 3, sel[i] ? TEXT : 0xFFB4BCD0, false);
            int idx = i;
            hits.add(new Hit(lx, cy1, lw, cy2 - cy1, () -> { sel[idx] = !sel[idx]; refreshCount(); }));
        }
        g.disableScissor();
        scrollbar(g, lx + lw - 3, ly + 1, lh - 2, content, scroll);
        zones.add(new Zone(lx, ly, lw, lh, d -> scroll = clamp(scroll - d * rowH * 3, 0, maxScroll)));
    }

    private void button(GuiGraphics g, int x, int y, int w, int h, String label, boolean active, boolean primary, Runnable r) {
        boolean hov = inside(mxPos, myPos, x, y, w, h);
        float ht = hover.t(x * 31 + y * 17 + w, hov);
        int bg = primary ? Anim.mix(ACCENT, 0xFF8279FF, ht) : active ? Anim.mix(ACCENT_DIM, 0xFF38337F, ht) : Anim.mix(PANEL2, HOVER, ht);
        int bd = primary || active ? ACCENT : Anim.mix(BORDER, 0xFF4A5372, ht);
        g.fill(x, y, x + w, y + h, bg);
        border(g, x, y, w, h, bd);
        String l = fit(label, w - 4);
        g.drawString(this.font, l, x + (w - this.font.width(l)) / 2, y + (h - 8) / 2 + 1,
            primary ? 0xFFFFFFFF : active ? TEXT : 0xFFB4BCD0, false);
        hits.add(new Hit(x, y, w, h, r));
    }

    private void border(GuiGraphics g, int x, int y, int w, int h, int c) {
        g.fill(x, y, x + w, y + 1, c);
        g.fill(x, y + h - 1, x + w, y + h, c);
        g.fill(x, y, x + 1, y + h, c);
        g.fill(x + w - 1, y, x + w, y + h, c);
    }

    private void scrollbar(GuiGraphics g, int x, int y, int h, int content, int sc) {
        if (content <= h) return;
        int thumb = Math.max(12, h * h / content);
        int ty = y + (int) ((long) (h - thumb) * sc / (content - h));
        g.fill(x, ty, x + 2, ty + thumb, 0xFF4A5372);
    }

    private static boolean inside(int px, int py, int x, int y, int w, int h) {
        return px >= x && px < x + w && py >= y && py < y + h;
    }

    private String fit(String s, int maxW) {
        if (maxW <= 0) return "";
        if (this.font.width(s) <= maxW) return s;
        while (!s.isEmpty() && this.font.width(s + "..") > maxW) s = s.substring(0, s.length() - 1);
        return s + "..";
    }
}
