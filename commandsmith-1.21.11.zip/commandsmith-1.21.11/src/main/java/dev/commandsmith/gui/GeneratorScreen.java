package dev.commandsmith.gui;

import dev.commandsmith.CommandSmithConfig;
import dev.commandsmith.data.CommandBuilder;
import dev.commandsmith.data.Enchants;
import dev.commandsmith.data.ItemCatalog;
import dev.commandsmith.data.StyledText;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.Consumer;
import java.util.function.IntConsumer;

/** Sharp, dark, immediate-mode style /give generator. */
public class GeneratorScreen extends Screen {
    // ---- theme -------------------------------------------------------------
    static final int BG = 0xFF0A0C11, PANEL = 0xFF11141B, PANEL2 = 0xFF181C26, BORDER = 0xFF2A3042;
    static final int ACCENT = 0xFF6C63FF, ACCENT_DIM = 0xFF2B2866, TEXT = 0xFFE8ECF4, MUTED = 0xFF8089A0;
    static final int HOVER = 0xFF222838, GOOD = 0xFF3DDC97, ENCH = 0xFF8EA7FF;

    private enum Tab {
        ARMOR("Armor"), TOOLS("Tools"), WEAPONS("Weapons"), ALL("All");
        final String label;
        Tab(String label) { this.label = label; }
    }

    private record Hit(int x, int y, int w, int h, Runnable action) {}
    private record Zone(int x, int y, int w, int h, IntConsumer onScroll) {}

    // ---- state -------------------------------------------------------------
    private final Screen parent;
    private final CommandBuilder cmd = new CommandBuilder();
    private ItemCatalog.Entry selected;
    private Tab tab = Tab.ARMOR;
    private String search = "";
    private List<ItemCatalog.Entry> filtered = List.of();
    private int itemScroll, enchScroll, cmdScroll;
    private String status = "";
    private long statusUntil;

    private EditBox searchBox, targetBox, countBox, levelBox;
    private String editingEnch;
    private boolean editDrawn;
    private final List<Hit> hits = new ArrayList<>();
    private final List<Zone> zones = new ArrayList<>();
    private int mxPos, myPos;

    // ---- layout ------------------------------------------------------------
    private int top, bottom, lx, lw, midX, midW, rx, rw;
    private int nameLabelY, nameCardY, loreLabelY, loreCardY, togY;
    private int enchLabelY, enchOptY, enchOpt2Y, enchTop;
    private int bigScale, bigSize, cardY, cardH, tgtLabelY, tgtY, targetW;
    private int countY, countPlusX, countBoxX, countMinusX, cmdLabelY, cmdY, btnY, cmdBottom;

    public GeneratorScreen(Screen parent) {
        super(Component.literal("CommandSmith"));
        this.parent = parent;
        cmd.target = CommandSmithConfig.target;
        select(ItemCatalog.byId("minecraft:diamond_chestplate"));
        refilter();
    }

    // ---- setup -------------------------------------------------------------
    @Override
    protected void init() {
        layout();
        searchBox = field(lx + 8, top + 26, lw - 16, "Search items...", 40, search, s -> { search = s; refilter(); });
        targetBox = field(rx + 8, tgtY, targetW, "@s", 40, cmd.target, s -> { cmd.target = s; CommandSmithConfig.target = s; });
        countBox = field(countBoxX, countY, 36, "1", 4, String.valueOf(cmd.count), s -> cmd.count = parseCount(s));
        countBox.setFilter(s -> s.matches("\\d{0,4}"));

        levelBox = new EditBox(this.font, 0, 0, 24, 10, Component.literal("Level"));
        levelBox.setBordered(false);
        levelBox.setMaxLength(3);
        levelBox.setFilter(s -> s.matches("\\d{0,3}"));
        levelBox.setResponder(this::onLevelTyped);
        this.addWidget(levelBox);
        editingEnch = null;
    }

    private EditBox field(int x, int y, int w, String hint, int max, String value, Consumer<String> onChange) {
        EditBox b = new EditBox(this.font, x + 4, y + 3, w - 8, 10, Component.literal(hint));
        b.setBordered(false);
        b.setMaxLength(max);
        b.setHint(Component.literal(hint));
        b.setValue(value);
        b.setResponder(onChange);
        this.addWidget(b); // rendered manually, on top of our panels
        return b;
    }

    private void layout() {
        int pad = 8, gap = 6;
        top = pad + 26;
        bottom = this.height - pad;
        int avail = this.width - pad * 2 - gap * 2;
        lw = Math.max(120, Math.min(220, avail * 28 / 100));
        rw = Math.max(130, Math.min(240, avail * 30 / 100));
        midW = Math.max(120, avail - lw - rw);
        lx = pad;
        midX = lx + lw + gap;
        rx = midX + midW + gap;

        nameLabelY = top + 8;
        nameCardY = top + 18;
        loreLabelY = top + 46;
        loreCardY = top + 56;
        togY = top + 84;
        enchLabelY = top + 106;
        enchOptY = top + 116;
        enchOpt2Y = top + 133;
        enchTop = top + 152;

        bigScale = rw >= 170 ? 3 : 2;
        bigSize = 16 * bigScale;
        cardY = top + 8;
        cardH = bigSize + 40;
        tgtLabelY = cardY + cardH + 6;
        tgtY = tgtLabelY + 10;
        targetW = rw - 16 - 3 * 24;
        countY = tgtY + 14 + 6;
        countPlusX = rx + rw - 8 - 14;
        countBoxX = countPlusX - 2 - 36;
        countMinusX = countBoxX - 2 - 14;
        cmdLabelY = countY + 14 + 6;
        cmdY = cmdLabelY + 10;
        btnY = bottom - 8 - 18;
        cmdBottom = btnY - 6;
    }

    // ---- logic -------------------------------------------------------------
    private static int parseCount(String s) {
        if (s == null || s.isEmpty()) return 1;
        try { return clamp(Integer.parseInt(s), 1, 9999); } catch (NumberFormatException e) { return 1; }
    }

    private static int clamp(int v, int lo, int hi) { return Math.max(lo, Math.min(hi, v)); }

    private void refilter() {
        String q = search.toLowerCase(Locale.ROOT).trim();
        List<ItemCatalog.Entry> out = new ArrayList<>();
        for (ItemCatalog.Entry e : ItemCatalog.all()) {
            if (tab != Tab.ALL && !tab.label.equals(e.category())) continue;
            if (!q.isEmpty() && !e.display().toLowerCase(Locale.ROOT).contains(q) && !e.path().contains(q)) continue;
            out.add(e);
        }
        filtered = out;
        itemScroll = 0;
    }

    private void select(ItemCatalog.Entry e) {
        if (e == null) {
            List<ItemCatalog.Entry> all = ItemCatalog.all();
            if (all.isEmpty()) return;
            e = all.get(0);
        }
        selected = e;
        cmd.itemId = e.id();
        if (!CommandSmithConfig.showAllEnchants) {
            cmd.enchants.keySet().removeIf(id -> {
                Enchants.Ench en = Enchants.byId(id);
                return en != null && !en.appliesTo(selected.group());
            });
        }
        enchScroll = 0;
    }

    private List<Enchants.Ench> visibleEnchants() {
        List<Enchants.Ench> out = new ArrayList<>();
        for (Enchants.Ench en : Enchants.ALL) {
            if (CommandSmithConfig.showAllEnchants || selected == null || en.appliesTo(selected.group())) out.add(en);
        }
        return out;
    }

    private int maxLevel(Enchants.Ench en) { return CommandSmithConfig.unsafeLevels ? 255 : en.max(); }

    private void setEnchant(Enchants.Ench en, int lvl) {
        lvl = clamp(lvl, 0, maxLevel(en));
        if (lvl <= 0) cmd.enchants.remove(en.id()); else cmd.enchants.put(en.id(), lvl);
    }

    private void startEdit(Enchants.Ench en, int lvl) {
        editingEnch = en.id();
        levelBox.setValue("");
        levelBox.setHint(Component.literal(String.valueOf(lvl)));
        this.setFocused(levelBox);
        levelBox.setFocused(true);
    }

    /** Level typed straight into the box: applied live. */
    private void onLevelTyped(String s) {
        if (editingEnch == null || s.isEmpty()) return;
        Enchants.Ench en = Enchants.byId(editingEnch);
        if (en == null) return;
        int v;
        try { v = Integer.parseInt(s); } catch (NumberFormatException e) { return; }
        int c = clamp(v, 0, maxLevel(en));
        setEnchant(en, c);
        if (c != v) levelBox.setValue(String.valueOf(c));
    }

    private void toggleUnsafe() {
        CommandSmithConfig.unsafeLevels = !CommandSmithConfig.unsafeLevels;
        if (!CommandSmithConfig.unsafeLevels) {
            for (var entry : cmd.enchants.entrySet()) {
                Enchants.Ench en = Enchants.byId(entry.getKey());
                if (en != null && entry.getValue() > en.max()) entry.setValue(en.max());
            }
        }
    }

    private void openEditor(TextEditorScreen.Mode mode) {
        this.minecraft.setScreen(new TextEditorScreen(this, mode, cmd));
    }

    private void flash(String s) {
        status = s;
        statusUntil = System.currentTimeMillis() + 2500;
    }

    private void copy() {
        this.minecraft.keyboardHandler.setClipboard("/" + cmd.build());
        flash("Copied!");
    }

    private void run() {
        if (this.minecraft.player == null) { flash("Join a world first"); return; }
        this.minecraft.player.connection.sendCommand(cmd.build());
        flash("Sent!");
    }

    @Override
    public void onClose() {
        CommandSmithConfig.save();
        this.minecraft.setScreen(this.parent);
    }

    // ---- input -------------------------------------------------------------
    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (event.button() == 0) {
            for (int i = hits.size() - 1; i >= 0; i--) {
                Hit h = hits.get(i);
                if (inside((int) event.x(), (int) event.y(), h.x, h.y, h.w, h.h)) {
                    this.setFocused(null);
                    h.action.run();
                    return true;
                }
            }
        }
        return super.mouseClicked(event, doubleClick);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        for (Zone z : zones) {
            if (inside((int) mouseX, (int) mouseY, z.x, z.y, z.w, z.h)) {
                z.onScroll.accept(scrollY > 0 ? 1 : -1);
                return true;
            }
        }
        return super.mouseScrolled(mouseX, mouseY, scrollX, scrollY);
    }

    // ---- render ------------------------------------------------------------
    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        renderUi(g, mouseX, mouseY, delta);
    }

    /** No super.render: our opaque UI replaces the vanilla background, and the editor reuses this as its backdrop. */
    void renderUi(GuiGraphics g, int mouseX, int mouseY, float delta) {
        hits.clear();
        zones.clear();
        mxPos = mouseX;
        myPos = mouseY;
        editDrawn = false;

        g.fill(0, 0, this.width, this.height, BG);
        drawTitle(g);
        drawItemPanel(g, delta);
        drawCustomizePanel(g, delta);
        drawOutputPanel(g, delta);

        if (editingEnch != null && (!editDrawn || !levelBox.isFocused())) editingEnch = null;
    }

    private void drawTitle(GuiGraphics g) {
        int x = 8, y = 8, w = this.width - 16, h = 22;
        g.fill(x, y, x + w, y + h, PANEL);
        border(g, x, y, w, h, BORDER);
        g.fill(x, y, x + 3, y + h, ACCENT);
        g.drawString(this.font, "COMMANDSMITH", x + 12, y + 7, TEXT, false);
        g.drawString(this.font, "GIVE GENERATOR", x + 12 + this.font.width("COMMANDSMITH") + 8, y + 7, ACCENT, false);
        String soon = "RANKS  (soon)";
        g.drawString(this.font, soon, x + w - 28 - this.font.width(soon) - 10, y + 7, 0xFF4B5268, false);
        button(g, x + w - 22, y + 2, 18, 18, "X", false, false, this::onClose);
    }

    private void drawItemPanel(GuiGraphics g, float delta) {
        panel(g, lx, top, lw, bottom - top);
        Tab[] tabs = Tab.values();
        int tw = (lw - 16 - (tabs.length - 1) * 2) / tabs.length;
        for (int i = 0; i < tabs.length; i++) {
            Tab t = tabs[i];
            button(g, lx + 8 + i * (tw + 2), top + 8, tw, 14, t.label, tab == t, false, () -> { tab = t; refilter(); });
        }
        fieldBg(g, lx + 8, top + 26, lw - 16, 14, searchBox);
        searchBox.render(g, mxPos, myPos, delta);

        int listX = lx + 8, listY = top + 46, listW = lw - 16, listH = bottom - 8 - listY;
        if (listH <= 0) return;
        g.fill(listX, listY, listX + listW, listY + listH, PANEL2);
        int rowH = 18, content = filtered.size() * rowH;
        int maxScroll = Math.max(0, content - listH);
        itemScroll = clamp(itemScroll, 0, maxScroll);

        g.enableScissor(listX, listY, listX + listW, listY + listH);
        if (filtered.isEmpty()) g.drawString(this.font, "No items", listX + 6, listY + 6, MUTED, false);
        for (int i = itemScroll / rowH; i < filtered.size(); i++) {
            int ry = listY + i * rowH - itemScroll;
            if (ry >= listY + listH) break;
            ItemCatalog.Entry e = filtered.get(i);
            boolean sel = selected != null && selected.id().equals(e.id());
            int cy1 = Math.max(ry, listY), cy2 = Math.min(ry + rowH, listY + listH);
            boolean hov = inside(mxPos, myPos, listX, cy1, listW, cy2 - cy1);
            if (sel) { g.fill(listX, ry, listX + listW, ry + rowH, ACCENT_DIM); g.fill(listX, ry, listX + 2, ry + rowH, ACCENT); }
            else if (hov) g.fill(listX, ry, listX + listW, ry + rowH, HOVER);
            g.renderItem(e.stack(), listX + 5, ry + 1);
            g.drawString(this.font, fit(e.display(), listW - 30), listX + 26, ry + 5, sel ? TEXT : 0xFFB4BCD0, false);
            hits.add(new Hit(listX, cy1, listW, cy2 - cy1, () -> select(e)));
        }
        g.disableScissor();
        scrollbar(g, listX + listW - 2, listY, listH, content, itemScroll);
        zones.add(new Zone(listX, listY, listW, listH, d -> itemScroll = clamp(itemScroll - d * rowH * 2, 0, maxScroll)));
    }

    private void drawCustomizePanel(GuiGraphics g, float delta) {
        panel(g, midX, top, midW, bottom - top);
        int ix = midX + 10, iw = midW - 20;

        label(g, "NAME", ix, nameLabelY);
        drawCard(g, ix, nameCardY, iw, TextEditorScreen.Mode.NAME);
        label(g, "LORE", ix, loreLabelY);
        drawCard(g, ix, loreCardY, iw, TextEditorScreen.Mode.LORE);

        int tw = (iw - 4) / 2;
        button(g, ix, togY, tw, 14, "Unbreakable", cmd.unbreakable, false, () -> cmd.unbreakable = !cmd.unbreakable);
        button(g, ix + tw + 4, togY, tw, 14, "Glint", cmd.glint, false, () -> cmd.glint = !cmd.glint);

        label(g, "ENCHANTMENTS", ix, enchLabelY);
        String sel = cmd.enchants.size() + " selected";
        g.drawString(this.font, sel, ix + iw - this.font.width(sel), enchLabelY, cmd.enchants.isEmpty() ? MUTED : ENCH, false);
        button(g, ix, enchOptY, tw, 14, "All enchants", CommandSmithConfig.showAllEnchants, false,
            () -> { CommandSmithConfig.showAllEnchants = !CommandSmithConfig.showAllEnchants; enchScroll = 0; });
        button(g, ix + tw + 4, enchOptY, tw, 14, "Unsafe levels", CommandSmithConfig.unsafeLevels, false, this::toggleUnsafe);
        button(g, ix, enchOpt2Y, tw, 14, "Max all", false, false,
            () -> { for (Enchants.Ench en : visibleEnchants()) cmd.enchants.put(en.id(), en.max()); });
        button(g, ix + tw + 4, enchOpt2Y, tw, 14, "Clear", false, false, () -> cmd.enchants.clear());

        int ly = enchTop, lh = bottom - 8 - ly;
        if (lh <= 0) return;
        g.fill(ix, ly, ix + iw, ly + lh, PANEL2);
        List<Enchants.Ench> list = visibleEnchants();
        int rowH = 14, content = list.size() * rowH;
        int maxScroll = Math.max(0, content - lh);
        enchScroll = clamp(enchScroll, 0, maxScroll);

        g.enableScissor(ix, ly, ix + iw, ly + lh);
        for (int i = 0; i < list.size(); i++) {
            int ry = ly + i * rowH - enchScroll;
            if (ry + rowH <= ly) continue;
            if (ry >= ly + lh) break;
            Enchants.Ench en = list.get(i);
            int lvl = cmd.enchants.getOrDefault(en.id(), 0);
            boolean on = lvl > 0;
            int cy1 = Math.max(ry, ly), cy2 = Math.min(ry + rowH, ly + lh);
            if (on) g.fill(ix, ry, ix + iw, ry + rowH, 0xFF1F1D45);
            else if (inside(mxPos, myPos, ix, cy1, iw - 68, cy2 - cy1)) g.fill(ix, ry, ix + iw, ry + rowH, HOVER);
            g.drawString(this.font, fit(en.name(), iw - 76), ix + 6, ry + 3, on ? TEXT : MUTED, false);
            hits.add(new Hit(ix, cy1, iw - 68, cy2 - cy1, () -> setEnchant(en, on ? 0 : 1)));

            int bx = ix + iw - 66;
            mini(g, bx, ry + 1, "-", ly, ly + lh, () -> setEnchant(en, lvl - 1));
            int lvX = bx + 16, lvW = 32;
            if (en.id().equals(editingEnch)) {
                g.fill(lvX, ry + 1, lvX + lvW, ry + 13, PANEL);
                border(g, lvX, ry + 1, lvW, 12, ACCENT);
                levelBox.setX(lvX + 4);
                levelBox.setY(ry + 3);
                levelBox.setWidth(lvW - 8);
                levelBox.render(g, mxPos, myPos, delta);
                editDrawn = true;
            } else {
                int hy1 = Math.max(ry + 1, ly), hy2 = Math.min(ry + 13, ly + lh);
                boolean hovL = hy2 > hy1 && inside(mxPos, myPos, lvX, hy1, lvW, hy2 - hy1);
                g.fill(lvX, ry + 1, lvX + lvW, ry + 13, PANEL);
                border(g, lvX, ry + 1, lvW, 12, hovL ? ACCENT : BORDER);
                String lv = String.valueOf(lvl);
                g.drawString(this.font, lv, lvX + (lvW - this.font.width(lv)) / 2, ry + 3, on ? ENCH : MUTED, false);
                if (hy2 > hy1) hits.add(new Hit(lvX, hy1, lvW, hy2 - hy1, () -> startEdit(en, lvl)));
            }
            mini(g, bx + 50, ry + 1, "+", ly, ly + lh, () -> setEnchant(en, lvl + 1));
        }
        g.disableScissor();
        scrollbar(g, ix + iw - 2, ly, lh, content, enchScroll);
        zones.add(new Zone(ix, ly, iw, lh, d -> enchScroll = clamp(enchScroll - d * rowH * 2, 0, maxScroll)));
    }

    /** Clickable summary card that opens the text editor on top of this screen. */
    private void drawCard(GuiGraphics g, int x, int y, int w, TextEditorScreen.Mode mode) {
        int h = 22, chipW = 34;
        boolean hov = inside(mxPos, myPos, x, y, w, h);
        g.fill(x, y, x + w, y + h, hov ? HOVER : PANEL2);
        border(g, x, y, w, h, hov ? ACCENT : BORDER);
        int tw = w - chipW - 14;
        if (mode == TextEditorScreen.Mode.NAME) {
            if (cmd.name.isBlank()) g.drawString(this.font, fit("Click to style a name...", tw), x + 6, y + 7, MUTED, false);
            else StyledRender.draw(g, this.font, cmd.name, x + 6, y + 7, tw);
        } else {
            List<StyledText> lines = cmd.loreForOutput();
            if (lines.isEmpty()) {
                g.drawString(this.font, fit("Click to add lore...", tw), x + 6, y + 7, MUTED, false);
            } else {
                String more = lines.size() > 1 ? "+" + (lines.size() - 1) : "";
                StyledRender.draw(g, this.font, lines.get(0), x + 6, y + 7, tw - this.font.width(more) - 4);
                if (!more.isEmpty()) g.drawString(this.font, more, x + w - chipW - 8 - this.font.width(more), y + 7, MUTED, false);
            }
        }
        int cx = x + w - chipW - 4;
        g.fill(cx, y + 4, cx + chipW, y + 18, ACCENT_DIM);
        border(g, cx, y + 4, chipW, 14, ACCENT);
        g.drawString(this.font, "EDIT", cx + (chipW - this.font.width("EDIT")) / 2, y + 7, TEXT, false);
        hits.add(new Hit(x, y, w, h, () -> openEditor(mode)));
    }

    private void drawOutputPanel(GuiGraphics g, float delta) {
        panel(g, rx, top, rw, bottom - top);
        int cx = rx + 8, cw = rw - 16;

        // preview card
        g.fill(cx, cardY, cx + cw, cardY + cardH, PANEL2);
        border(g, cx, cardY, cw, cardH, BORDER);
        if (selected != null) {
            ItemStack st = new ItemStack(selected.item());
            if (cmd.glint || !cmd.enchants.isEmpty()) st.set(DataComponents.ENCHANTMENT_GLINT_OVERRIDE, Boolean.TRUE);
            var pose = g.pose();
            pose.pushMatrix();
            pose.translate((float) (cx + 8), (float) (cardY + 8));
            pose.scale((float) bigScale, (float) bigScale);
            g.renderItem(st, 0, 0);
            pose.popMatrix();

            int tx = cx + 8 + bigSize + 8, tw = cx + cw - 6 - tx;
            if (cmd.name.isBlank()) g.drawString(this.font, fit(selected.display(), tw), tx, cardY + 10, TEXT, false);
            else StyledRender.draw(g, this.font, cmd.name, tx, cardY + 10, tw);
            g.drawString(this.font, fit(selected.id(), tw), tx, cardY + 22, MUTED, false);
            g.drawString(this.font, "x" + cmd.count + " -> " + fit(cmd.target.isBlank() ? "@s" : cmd.target, tw - 30), tx, cardY + 34, 0xFF5E6780, false);

            int iy = cardY + 8 + bigSize + 6, drawn = 0;
            for (StyledText l : cmd.loreForOutput()) {
                if (drawn >= 2) break;
                StyledRender.draw(g, this.font, l, cx + 8, iy + drawn * 10, cw - 16);
                drawn++;
            }
            if (drawn < 2 && !cmd.enchants.isEmpty()) {
                List<String> parts = new ArrayList<>();
                for (var e : cmd.enchants.entrySet()) {
                    Enchants.Ench en = Enchants.byId(e.getKey());
                    parts.add((en == null ? e.getKey() : en.name()) + " " + Enchants.roman(e.getValue()));
                }
                for (String l : wrap(String.join(", ", parts), cw - 16)) {
                    if (drawn >= 2) break;
                    g.drawString(this.font, l, cx + 8, iy + drawn * 10, ENCH, false);
                    drawn++;
                }
            }
        }

        // target
        label(g, "TARGET", cx, tgtLabelY);
        fieldBg(g, cx, tgtY, targetW, 14, targetBox);
        targetBox.render(g, mxPos, myPos, delta);
        String[] sels = {"@s", "@p", "@a"};
        for (int i = 0; i < 3; i++) {
            String s = sels[i];
            button(g, cx + targetW + 2 + i * 24, tgtY, 22, 14, s, cmd.target.trim().equals(s), false, () -> targetBox.setValue(s));
        }

        // count (type it, or use +/-)
        label(g, "COUNT", cx, countY + 3);
        button(g, countMinusX, countY, 14, 14, "-", false, false, () -> countBox.setValue(String.valueOf(clamp(cmd.count - 1, 1, 9999))));
        fieldBg(g, countBoxX, countY, 36, 14, countBox);
        countBox.render(g, mxPos, myPos, delta);
        button(g, countPlusX, countY, 14, 14, "+", false, false, () -> countBox.setValue(String.valueOf(clamp(cmd.count + 1, 1, 9999))));

        // command box
        label(g, "COMMAND", cx, cmdLabelY);
        if (System.currentTimeMillis() < statusUntil) {
            g.drawString(this.font, status, cx + cw - this.font.width(status), cmdLabelY, GOOD, false);
        }
        int bh = cmdBottom - cmdY;
        if (bh > 8) {
            g.fill(cx, cmdY, cx + cw, cmdY + bh, 0xFF0D1017);
            border(g, cx, cmdY, cw, bh, BORDER);
            List<String> lines = wrapCmd("/" + cmd.build(), cw - 10);
            int lineH = 10, content = lines.size() * lineH, viewH = bh - 8;
            int maxScroll = Math.max(0, content - viewH);
            cmdScroll = clamp(cmdScroll, 0, maxScroll);
            g.enableScissor(cx + 1, cmdY + 1, cx + cw - 1, cmdY + bh - 1);
            for (int i = 0; i < lines.size(); i++) {
                int y = cmdY + 4 + i * lineH - cmdScroll;
                if (y + lineH < cmdY || y > cmdY + bh) continue;
                g.drawString(this.font, lines.get(i), cx + 5, y, 0xFFBFC8E0, false);
            }
            g.disableScissor();
            scrollbar(g, cx + cw - 3, cmdY + 1, bh - 2, content, cmdScroll);
            zones.add(new Zone(cx, cmdY, cw, bh, d -> cmdScroll = clamp(cmdScroll - d * lineH * 2, 0, maxScroll)));
        }

        int half = (cw - 4) / 2;
        button(g, cx, btnY, half, 18, "COPY", false, false, this::copy);
        button(g, cx + half + 4, btnY, cw - half - 4, 18, "RUN", false, true, this::run);
    }

    // ---- widgets / helpers ---------------------------------------------------
    private void button(GuiGraphics g, int x, int y, int w, int h, String label, boolean active, boolean primary, Runnable r) {
        boolean hov = inside(mxPos, myPos, x, y, w, h);
        int bg = primary ? (hov ? 0xFF8279FF : ACCENT) : active ? ACCENT_DIM : hov ? HOVER : PANEL2;
        int bd = primary || active ? ACCENT : hov ? 0xFF3C4560 : BORDER;
        g.fill(x, y, x + w, y + h, bg);
        border(g, x, y, w, h, bd);
        String l = fit(label, w - 4);
        g.drawString(this.font, l, x + (w - this.font.width(l)) / 2, y + (h - 8) / 2 + 1,
            primary ? 0xFFFFFFFF : active ? TEXT : 0xFFB4BCD0, false);
        hits.add(new Hit(x, y, w, h, r));
    }

    /** Small button inside a scrolling list; its hit area is clipped to the list. */
    private void mini(GuiGraphics g, int x, int y, String label, int clipTop, int clipBottom, Runnable r) {
        int w = 14, h = 12;
        int cy1 = Math.max(y, clipTop), cy2 = Math.min(y + h, clipBottom);
        boolean hov = cy2 > cy1 && inside(mxPos, myPos, x, cy1, w, cy2 - cy1);
        g.fill(x, y, x + w, y + h, hov ? ACCENT_DIM : PANEL);
        border(g, x, y, w, h, hov ? ACCENT : BORDER);
        g.drawString(this.font, label, x + (w - this.font.width(label)) / 2, y + 2, TEXT, false);
        if (cy2 > cy1) hits.add(new Hit(x, cy1, w, cy2 - cy1, r));
    }

    private void panel(GuiGraphics g, int x, int y, int w, int h) {
        g.fill(x, y, x + w, y + h, PANEL);
        border(g, x, y, w, h, BORDER);
    }

    private void fieldBg(GuiGraphics g, int x, int y, int w, int h, EditBox box) {
        g.fill(x, y, x + w, y + h, PANEL2);
        border(g, x, y, w, h, box != null && box.isFocused() ? ACCENT : BORDER);
    }

    private void border(GuiGraphics g, int x, int y, int w, int h, int c) {
        g.fill(x, y, x + w, y + 1, c);
        g.fill(x, y + h - 1, x + w, y + h, c);
        g.fill(x, y, x + 1, y + h, c);
        g.fill(x + w - 1, y, x + w, y + h, c);
    }

    private void label(GuiGraphics g, String s, int x, int y) {
        g.drawString(this.font, s, x, y, MUTED, false);
    }

    private void scrollbar(GuiGraphics g, int x, int y, int h, int content, int scroll) {
        if (content <= h) return;
        int thumb = Math.max(12, h * h / content);
        int ty = y + (int) ((long) (h - thumb) * scroll / (content - h));
        g.fill(x, ty, x + 2, ty + thumb, 0xFF4A5372);
    }

    private static boolean inside(int px, int py, int x, int y, int w, int h) {
        return px >= x && px < x + w && py >= y && py < y + h;
    }

    private String fit(String s, int maxW) {
        if (maxW <= 0) return "";
        if (this.font.width(s) <= maxW) return s;
        while (!s.isEmpty() && this.font.width(s + "..") > maxW) s = s.substring(0, s.length() - 1);
        return s + "..";
    }

    private List<String> wrap(String s, int maxW) {
        List<String> out = new ArrayList<>();
        StringBuilder line = new StringBuilder();
        for (char c : s.toCharArray()) {
            if (this.font.width(line.toString() + c) > maxW && line.length() > 0) {
                out.add(line.toString());
                line.setLength(0);
            }
            line.append(c);
        }
        if (line.length() > 0) out.add(line.toString());
        return out;
    }

    private String wrapKey = "";
    private List<String> wrapped = List.of();

    private List<String> wrapCmd(String s, int w) {
        String key = w + "|" + s;
        if (!key.equals(wrapKey)) {
            wrapKey = key;
            wrapped = wrap(s, w);
        }
        return wrapped;
    }
}
