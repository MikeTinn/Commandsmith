package dev.commandsmith.gui;

import com.google.gson.JsonObject;
import dev.commandsmith.data.CommandBuilder;
import dev.commandsmith.data.ItemCatalog;
import dev.commandsmith.data.PresetStore;
import dev.commandsmith.data.PresetStore.Preset;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.IntConsumer;

import static dev.commandsmith.gui.GeneratorScreen.*;

/** Shulker-box presets: a grid of folders, each holding saved items. Opens on top of the generator. */
public class PresetsScreen extends Screen {
    public enum Mode { BROWSE, SAVE_TO }

    private record Hit(int x, int y, int w, int h, Runnable action) {}
    private record Zone(int x, int y, int w, int h, IntConsumer onScroll) {}

    private final GeneratorScreen parent;
    private final CommandBuilder cmd;
    private Mode mode;

    private Preset open;
    private JsonObject selItem;
    private EditBox nameBox;
    private boolean suppress;
    private int gridScroll, listScroll;
    private String confirmKey = "";
    private long confirmUntil;
    private String msg = "";
    private long msgUntil;

    private final List<String> runQueue = new ArrayList<>();
    private int runTotal, runTick;
    private final Map<JsonObject, CommandBuilder> parsed = new IdentityHashMap<>();

    private final List<Hit> hits = new ArrayList<>();
    private final List<Zone> zones = new ArrayList<>();
    private int mxPos, myPos;
    private final Anim.Hover hover = new Anim.Hover();
    private final long openAt = System.currentTimeMillis();
    private long closeAt;

    private int ox, oy, ow, oh, ct, cb, lx2;

    public PresetsScreen(GeneratorScreen parent, CommandBuilder cmd, Mode mode) {
        super(Component.literal("Presets"));
        this.parent = parent;
        this.cmd = cmd;
        this.mode = mode;
    }

    // ---- setup -------------------------------------------------------------
    @Override
    protected void init() {
        parent.resize(this.minecraft, this.width, this.height);
        ow = Math.min(470, this.width - 16);
        oh = Math.min(256, this.height - 16);
        ox = (this.width - ow) / 2;
        oy = (this.height - oh) / 2;
        ct = oy + 30;
        cb = oy + oh - 30;
        lx2 = ox + 10;

        nameBox = new EditBox(this.font, lx2 + 56 + 4, ct + 3, 190 - 8, 10, Component.literal("Preset name"));
        nameBox.setBordered(false);
        nameBox.setMaxLength(32);
        nameBox.setHint(Component.literal("Preset name"));
        nameBox.setValue(open == null ? "" : open.name);
        nameBox.setResponder(s -> { if (!suppress && open != null) open.name = s; });
        this.addWidget(nameBox);
    }

    private static int clamp(int v, int lo, int hi) { return Math.max(lo, Math.min(hi, v)); }

    // ---- logic -------------------------------------------------------------
    private CommandBuilder parsedOf(JsonObject it) {
        return parsed.computeIfAbsent(it, k -> {
            CommandBuilder b = new CommandBuilder();
            b.loadFrom(k);
            return b;
        });
    }

    private void say(String s) {
        msg = s;
        msgUntil = System.currentTimeMillis() + 2500;
    }

    private void openFolder(Preset p) {
        open = p;
        PresetStore.activeId = p.id;
        selItem = p.items.isEmpty() ? null : p.items.get(0);
        listScroll = 0;
        confirmKey = "";
        suppress = true;
        nameBox.setValue(p.name);
        suppress = false;
    }

    private void newPreset() {
        Preset p = PresetStore.create();
        if (mode == Mode.SAVE_TO) {
            JsonObject d = cmd.toJson();
            p.items.add(d);
            parent.setLoaded(d);
            parent.flash("Saved to " + p.name);
            mode = Mode.BROWSE;
            PresetStore.save();
            openFolder(p);
            say("Saved! You can rename the preset above.");
        } else {
            openFolder(p);
        }
        this.setFocused(nameBox);
        nameBox.setFocused(true);
    }

    private void saveTo(Preset p) {
        JsonObject d = cmd.toJson();
        p.items.add(d);
        PresetStore.activeId = p.id;
        PresetStore.save();
        parent.setLoaded(d);
        parent.flash("Saved to " + p.name);
        onClose();
    }

    private void loadItem() {
        if (selItem == null) return;
        cmd.loadFrom(selItem);
        parent.syncFromCmd();
        parent.setLoaded(selItem);
        parent.flash("Loaded!");
        onClose();
    }

    private void addCurrent() {
        if (open == null) return;
        JsonObject d = cmd.toJson();
        open.items.add(d);
        selItem = d;
        listScroll = 1_000_000;
        PresetStore.save();
        say("Added the current item");
    }

    private boolean armed(String key) {
        return confirmKey.equals(key) && System.currentTimeMillis() < confirmUntil;
    }

    private void arm(String key) {
        confirmKey = key;
        confirmUntil = System.currentTimeMillis() + 3000;
    }

    private void deleteItem() {
        if (open == null || selItem == null) return;
        if (!armed("item")) { arm("item"); return; }
        int idx = PresetStore.indexOf(open.items, selItem);
        if (idx >= 0) open.items.remove(idx);
        parent.clearLoadedIf(selItem);
        parsed.remove(selItem);
        selItem = open.items.isEmpty() ? null : open.items.get(Math.min(Math.max(idx, 0), open.items.size() - 1));
        confirmKey = "";
        PresetStore.save();
    }

    private void deletePreset() {
        if (open == null) return;
        if (!armed("preset")) { arm("preset"); return; }
        PresetStore.PRESETS.remove(open);
        if (open.id.equals(PresetStore.activeId)) PresetStore.activeId = null;
        open = null;
        selItem = null;
        confirmKey = "";
        PresetStore.save();
    }

    private void runAll() {
        if (open == null || open.items.isEmpty()) return;
        if (this.minecraft.player == null) { say("Join a world first"); return; }
        runQueue.clear();
        for (JsonObject it : open.items) {
            CommandBuilder b = parsedOf(it);
            String old = b.target;
            b.target = cmd.target;
            runQueue.add(b.build());
            b.target = old;
        }
        runTotal = runQueue.size();
        runTick = 0;
    }

    /** Sends one queued command every few ticks so servers don't see it as spam. */
    @Override
    public void tick() {
        super.tick();
        if (runQueue.isEmpty()) return;
        if (++runTick >= 4) {
            runTick = 0;
            String c = runQueue.remove(0);
            if (this.minecraft.player != null) this.minecraft.player.connection.sendCommand(c);
            if (runQueue.isEmpty()) say("Ran " + runTotal + " command" + (runTotal == 1 ? "" : "s"));
        }
    }

    @Override
    public void onClose() {
        PresetStore.save();
        if (closeAt == 0) closeAt = System.currentTimeMillis();
    }

    // ---- input -------------------------------------------------------------
    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (closeAt != 0) return true;
        if (event.button() == 0) {
            for (int i = hits.size() - 1; i >= 0; i--) {
                Hit h = hits.get(i);
                if (inside((int) event.x(), (int) event.y(), h.x, h.y, h.w, h.h)) {
                    this.setFocused(null);
                    h.action.run();
                    return true;
                }
            }
        }
        return super.mouseClicked(event, doubleClick);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        for (Zone z : zones) {
            if (inside((int) mouseX, (int) mouseY, z.x, z.y, z.w, z.h)) {
                z.onScroll.accept(scrollY > 0 ? 1 : -1);
                return true;
            }
        }
        return super.mouseScrolled(mouseX, mouseY, scrollX, scrollY);
    }

    // ---- render ------------------------------------------------------------
    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        Anim.frame();
        if (closeAt != 0 && Anim.progress(closeAt, 140) >= 1f) {
            this.minecraft.setScreen(this.parent);
        }
        hits.clear();
        zones.clear();
        mxPos = mouseX;
        myPos = mouseY;
        nameBox.visible = open != null;

        float vis = Anim.ease(Anim.progress(openAt, 200)) * (closeAt == 0 ? 1f : 1f - Anim.ease(Anim.progress(closeAt, 140)));
        parent.renderUi(g, -10000, -10000, delta);
        g.fill(0, 0, this.width, this.height, ((int) (200 * vis)) << 24);
        var slide = g.pose();
        slide.pushMatrix();
        slide.translate(0f, (1f - vis) * 12f);

        g.fill(ox, oy, ox + ow, oy + oh, PANEL);
        border(g, ox, oy, ow, oh, BORDER);
        g.fill(ox, oy, ox + ow, oy + 22, PANEL2);
        g.fill(ox, oy + 22, ox + ow, oy + 23, BORDER);
        g.fill(ox, oy, ox + 3, oy + 22, ACCENT);
        String title = mode == Mode.SAVE_TO ? "SAVE TO PRESET" : "PRESETS";
        g.drawString(this.font, title, ox + 12, oy + 7, TEXT, false);
        g.drawString(this.font, "shulker box folders", ox + 12 + this.font.width(title) + 8, oy + 7, MUTED, false);
        button(g, ox + ow - 22, oy + 2, 18, 18, "X", false, false, this::onClose);

        if (open == null) drawGrid(g); else drawFolder(g, delta);

        String foot;
        int footColor = MUTED;
        if (!runQueue.isEmpty()) { foot = "Running " + (runTotal - runQueue.size()) + "/" + runTotal + "..."; footColor = ENCH; }
        else if (System.currentTimeMillis() < msgUntil) { foot = msg; footColor = GOOD; }
        else if (open == null) foot = "Save updates the item you loaded. Save to adds a new one.";
        else foot = "Select an item, then Load to edit it in the generator.";
        g.drawString(this.font, fit(foot, ow - 20 - 90 - 12), ox + 10, oy + oh - 23, footColor, false);
        button(g, ox + ow - 10 - 90, oy + oh - 10 - 18, 90, 18, mode == Mode.SAVE_TO ? "CANCEL" : "DONE", false, true, this::onClose);

        int cover = (int) ((1f - vis) * 255f);
        if (cover > 0) g.fill(ox, oy, ox + ow, oy + oh, (cover << 24) | 0x0A0C11);
        slide.popMatrix();
    }

    private void drawGrid(GuiGraphics g) {
        label(g, mode == Mode.SAVE_TO ? "Choose where to save the current item" : "Your presets  (click one to open it)", lx2, ct);
        int gx = lx2, gy = ct + 14, gw = ow - 20, gh = cb - gy;
        int gap = 8, cols = Math.max(1, (gw + gap) / (90 + gap));
        int cardW = (gw - (cols - 1) * gap) / cols, cardH = 84;
        int count = PresetStore.PRESETS.size() + 1;
        int rows = (count + cols - 1) / cols;
        int content = rows * (cardH + gap) + 2;
        int maxScroll = Math.max(0, content - gh);
        gridScroll = clamp(gridScroll, 0, maxScroll);

        g.enableScissor(gx, gy, gx + gw, gy + gh);
        for (int i = 0; i < count; i++) {
            int cx = gx + (i % cols) * (cardW + gap);
            int cy = gy + 2 + (i / cols) * (cardH + gap) - gridScroll;
            if (cy + cardH + 2 <= gy || cy >= gy + gh) continue;
            boolean isNew = i == PresetStore.PRESETS.size();
            int cy1 = Math.max(cy, gy), cy2 = Math.min(cy + cardH, gy + gh);
            boolean hov = cy2 > cy1 && inside(mxPos, myPos, cx, cy1, cardW, cy2 - cy1);
            float t = hover.t(5000 + i, hov);
            int y0 = cy + Math.round(t * -2f); // tiny lift on hover
            g.fill(cx, y0, cx + cardW, y0 + cardH, Anim.mix(PANEL2, HOVER, t));
            border(g, cx, y0, cardW, cardH, Anim.mix(BORDER, ACCENT, t));
            Runnable action;
            if (isNew) {
                var pose = g.pose();
                pose.pushMatrix();
                pose.translate((float) (cx + cardW / 2 - 8), (float) (y0 + 20));
                pose.scale(3f, 3f);
                g.drawString(this.font, "+", 0, 0, Anim.mix(MUTED, ACCENT, t), false);
                pose.popMatrix();
                String nm = "New preset";
                g.drawString(this.font, nm, cx + (cardW - this.font.width(nm)) / 2, y0 + 66, MUTED, false);
                action = this::newPreset;
            } else {
                Preset p = PresetStore.PRESETS.get(i);
                ItemCatalog.Entry e = ItemCatalog.byId(PresetStore.shulkerId(p.color));
                if (e != null) drawBig(g, e.stack(), cx + (cardW - 48) / 2, y0 + 8, 3);
                String nm = fit(p.name, cardW - 10);
                g.drawString(this.font, nm, cx + (cardW - this.font.width(nm)) / 2, y0 + 60, TEXT, false);
                String info = p.items.size() + (p.items.size() == 1 ? " item" : " items");
                g.drawString(this.font, info, cx + (cardW - this.font.width(info)) / 2, y0 + 71, MUTED, false);
                if (p.id.equals(PresetStore.activeId)) g.fill(cx + cardW - 9, y0 + 5, cx + cardW - 4, y0 + 10, ACCENT);
                action = mode == Mode.SAVE_TO ? () -> saveTo(p) : () -> openFolder(p);
            }
            if (cy2 > cy1) hits.add(new Hit(cx, cy1, cardW, cy2 - cy1, action));
        }
        g.disableScissor();
        scrollbar(g, gx + gw - 2, gy, gh, content, gridScroll);
        zones.add(new Zone(gx, gy, gw, gh, d -> gridScroll = clamp(gridScroll - d * 30, 0, maxScroll)));
    }

    private void drawFolder(GuiGraphics g, float delta) {
        Preset p = open;
        button(g, lx2, ct, 50, 14, "< Back", false, false, () -> { PresetStore.save(); open = null; selItem = null; });
        fieldBg(g, lx2 + 56, ct, 190, 14, nameBox);
        nameBox.render(g, mxPos, myPos, delta);
        boolean pArmed = armed("preset");
        button(g, ox + ow - 10 - 96, ct, 96, 14, pArmed ? "Click to confirm" : "Delete preset", pArmed, false, this::deletePreset);

        // item list
        int listW = (ow - 30) * 58 / 100, ly = ct + 32, lh = cb - ly, rowH = 26;
        label(g, "ITEMS  (" + p.items.size() + ")", lx2, ct + 20);
        g.fill(lx2, ly, lx2 + listW, ly + lh, PANEL2);
        border(g, lx2, ly, listW, lh, BORDER);
        int content = p.items.size() * rowH;
        int maxScroll = Math.max(0, content - lh);
        listScroll = clamp(listScroll, 0, maxScroll);
        g.enableScissor(lx2 + 1, ly + 1, lx2 + listW - 1, ly + lh - 1);
        if (p.items.isEmpty()) {
            g.drawString(this.font, "Empty - use 'Add current item'", lx2 + 8, ly + 8, MUTED, false);
        }
        for (int i = 0; i < p.items.size(); i++) {
            int ry = ly + i * rowH - listScroll;
            if (ry + rowH <= ly) continue;
            if (ry >= ly + lh) break;
            JsonObject it = p.items.get(i);
            CommandBuilder cb2 = parsedOf(it);
            ItemCatalog.Entry e = ItemCatalog.byId(cb2.itemId);
            boolean on = it == selItem;
            int cy1 = Math.max(ry, ly), cy2 = Math.min(ry + rowH, ly + lh);
            boolean hov = inside(mxPos, myPos, lx2, cy1, listW, cy2 - cy1);
            float t = hover.t(6000 + i, hov);
            if (on) { g.fill(lx2 + 1, ry, lx2 + listW - 1, ry + rowH, ACCENT_DIM); g.fill(lx2 + 1, ry, lx2 + 3, ry + rowH, ACCENT); }
            else if (t > 0f) g.fill(lx2 + 1, ry, lx2 + listW - 1, ry + rowH, Anim.mix(PANEL2, HOVER, t));
            if (e != null) g.renderItem(e.stack(), lx2 + 7, ry + 5);
            int tx = lx2 + 29, tw = listW - 40;
            if (!cb2.name.isBlank()) StyledRender.draw(g, this.font, cb2.name, tx, ry + 4, tw);
            else g.drawString(this.font, fit(e == null ? cb2.itemId : e.display(), tw), tx, ry + 4, TEXT, false);
            String info = "x" + cb2.count
                + (cb2.enchants.isEmpty() ? "" : "   " + cb2.enchants.size() + " ench")
                + (cb2.attrs.isEmpty() ? "" : "   " + cb2.attrs.size() + " attr");
            g.drawString(this.font, fit(info, tw), tx, ry + 14, MUTED, false);
            hits.add(new Hit(lx2, cy1, listW, cy2 - cy1, () -> { selItem = it; confirmKey = ""; }));
        }
        g.disableScissor();
        scrollbar(g, lx2 + listW - 3, ly + 1, lh - 2, content, listScroll);
        zones.add(new Zone(lx2, ly, listW, lh, d -> listScroll = clamp(listScroll - d * rowH, 0, maxScroll)));

        // right column: icon + actions
        int rx3 = lx2 + listW + 10, rw3 = ox + ow - 10 - rx3;
        label(g, "ICON", rx3, ct + 20);
        int per = Math.max(1, (rw3 + 2) / 20);
        for (int i = 0; i < PresetStore.COLORS.length; i++) {
            String col = PresetStore.COLORS[i];
            int ix = rx3 + (i % per) * 20, iy = ct + 32 + (i / per) * 20;
            boolean on = p.color.equals(col);
            boolean hov = inside(mxPos, myPos, ix, iy, 18, 18);
            float t = hover.t(7000 + i, hov);
            g.fill(ix, iy, ix + 18, iy + 18, Anim.mix(PANEL2, HOVER, t));
            border(g, ix, iy, 18, 18, on ? ACCENT : Anim.mix(BORDER, 0xFF4A5372, t));
            ItemCatalog.Entry e = ItemCatalog.byId(PresetStore.shulkerId(col));
            if (e != null) g.renderItem(e.stack(), ix + 1, iy + 1 - Math.round(t * 2f));
            hits.add(new Hit(ix, iy, 18, 18, () -> { p.color = col; PresetStore.save(); }));
        }
        int iconRows = (PresetStore.COLORS.length + per - 1) / per;
        int by = ct + 32 + iconRows * 20 + 6, bh = 14, step = bh + 4;
        boolean has = selItem != null;
        boolean iArmed = armed("item");

        if (has) button(g, rx3, by, rw3, bh, "Load into generator", false, false, this::loadItem);
        else disabledButton(g, rx3, by, rw3, bh, "Load into generator");
        button(g, rx3, by + step, rw3, bh, "Add current item", false, false, this::addCurrent);
        if (has) button(g, rx3, by + 2 * step, rw3, bh, iArmed ? "Click to confirm" : "Delete item", iArmed, false, this::deleteItem);
        else disabledButton(g, rx3, by + 2 * step, rw3, bh, "Delete item");
        if (!p.items.isEmpty()) button(g, rx3, by + 3 * step + 2, rw3, 16, "Run all (" + p.items.size() + ")", false, true, this::runAll);
        else disabledButton(g, rx3, by + 3 * step + 2, rw3, 16, "Run all (0)");
    }

    // ---- helpers -------------------------------------------------------------
    private void drawBig(GuiGraphics g, ItemStack st, int x, int y, int s) {
        var pose = g.pose();
        pose.pushMatrix();
        pose.translate((float) x, (float) y);
        pose.scale((float) s, (float) s);
        g.renderItem(st, 0, 0);
        pose.popMatrix();
    }

    private void button(GuiGraphics g, int x, int y, int w, int h, String label, boolean active, boolean primary, Runnable r) {
        boolean hov = inside(mxPos, myPos, x, y, w, h);
        float ht = hover.t(x * 31 + y * 17 + w, hov);
        int bg = primary ? Anim.mix(ACCENT, 0xFF8279FF, ht) : active ? Anim.mix(ACCENT_DIM, 0xFF38337F, ht) : Anim.mix(PANEL2, HOVER, ht);
        int bd = primary || active ? ACCENT : Anim.mix(BORDER, 0xFF4A5372, ht);
        g.fill(x, y, x + w, y + h, bg);
        border(g, x, y, w, h, bd);
        String l = fit(label, w - 4);
        g.drawString(this.font, l, x + (w - this.font.width(l)) / 2, y + (h - 8) / 2 + 1,
            primary ? 0xFFFFFFFF : active ? TEXT : 0xFFB4BCD0, false);
        hits.add(new Hit(x, y, w, h, r));
    }

    private void disabledButton(GuiGraphics g, int x, int y, int w, int h, String label) {
        g.fill(x, y, x + w, y + h, PANEL);
        border(g, x, y, w, h, BORDER);
        String l = fit(label, w - 4);
        g.drawString(this.font, l, x + (w - this.font.width(l)) / 2, y + (h - 8) / 2 + 1, 0xFF4B5268, false);
    }

    private void fieldBg(GuiGraphics g, int x, int y, int w, int h, EditBox box) {
        g.fill(x, y, x + w, y + h, PANEL2);
        border(g, x, y, w, h, box != null && box.isFocused() ? ACCENT : BORDER);
    }

    private void border(GuiGraphics g, int x, int y, int w, int h, int c) {
        g.fill(x, y, x + w, y + 1, c);
        g.fill(x, y + h - 1, x + w, y + h, c);
        g.fill(x, y, x + 1, y + h, c);
        g.fill(x + w - 1, y, x + w, y + h, c);
    }

    private void label(GuiGraphics g, String s, int x, int y) {
        g.drawString(this.font, s, x, y, MUTED, false);
    }

    private void scrollbar(GuiGraphics g, int x, int y, int h, int content, int scroll) {
        if (content <= h) return;
        int thumb = Math.max(12, h * h / content);
        int ty = y + (int) ((long) (h - thumb) * scroll / (content - h));
        g.fill(x, ty, x + 2, ty + thumb, 0xFF4A5372);
    }

    private static boolean inside(int px, int py, int x, int y, int w, int h) {
        return px >= x && px < x + w && py >= y && py < y + h;
    }

    private String fit(String s, int maxW) {
        if (maxW <= 0) return "";
        if (this.font.width(s) <= maxW) return s;
        while (!s.isEmpty() && this.font.width(s + "..") > maxW) s = s.substring(0, s.length() - 1);
        return s + "..";
    }
}
