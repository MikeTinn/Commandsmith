package dev.commandsmith.gui;

import dev.commandsmith.ChatHistory;
import dev.commandsmith.CommandQueue;
import dev.commandsmith.CommandSmithConfig;
import dev.commandsmith.data.AttrMod;
import dev.commandsmith.data.TeamParser;
import dev.commandsmith.data.TeamParser.Member;
import dev.commandsmith.data.TeamParser.Role;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.IntConsumer;

import static dev.commandsmith.gui.GeneratorScreen.*;

/**
 * LuckPerms tab: pull the team's names out of chat (/team info), then queue
 * "lp user <ign> parent addtemp <rank> <duration>" for all of them.
 */
public class RanksScreen extends Screen {
    private record Hit(int x, int y, int w, int h, Runnable action) {}
    private record Zone(int x, int y, int w, int h, IntConsumer onScroll) {}

    private static final String[] DURATIONS = {"1d", "3d", "7d", "14d", "30d"};

    private final Screen parent;
    private final GeneratorScreen gen;
    private final List<Member> members = new ArrayList<>();
    private int teamScroll, queueScroll;
    private String status = "";
    private long statusUntil;

    private EditBox rankBox, durBox, nameBox, batchBox, delayBox;
    private final List<Hit> hits = new ArrayList<>();
    private final List<Zone> zones = new ArrayList<>();
    private int mxPos, myPos;
    private final Anim.Hover hover = new Anim.Hover();
    private long openAt = System.currentTimeMillis();

    // layout
    private int top, bottom, lx, lw, midX, midW, rx, rw;
    private int addY, rankY, recentY, durLabelY, durY, durChipsY, prevLabelY, prevY, addBtnY;
    private int sizeLabelY, sizeY, halfW, infoY, queueLabelY, queueTop, startY, clearY;

    public RanksScreen(Screen parent, GeneratorScreen gen) {
        super(Component.literal("Ranks"));
        this.parent = parent;
        this.gen = gen;
    }

    void replay() { openAt = System.currentTimeMillis(); }

    void setMembers(List<Member> ms) {
        members.clear();
        members.addAll(ms);
        teamScroll = 0;
    }

    void say(String s) {
        status = s;
        statusUntil = System.currentTimeMillis() + 3000;
    }

    // ---- setup -------------------------------------------------------------
    @Override
    protected void init() {
        layout();
        rankBox = field(midX + 10, rankY, midW - 20, "rank name, e.g. vip", 32, CommandSmithConfig.rank, s -> CommandSmithConfig.rank = s);
        rankBox.setFilter(s -> s.matches("[A-Za-z0-9_.\\-]*"));
        durBox = field(midX + 10, durY, midW - 20, "7d", 12, CommandSmithConfig.duration, s -> CommandSmithConfig.duration = s);
        durBox.setFilter(s -> s.matches("[A-Za-z0-9]*"));
        nameBox = field(lx + 8, addY, lw - 16 - 22, "Add a name...", 16, "", s -> { });
        nameBox.setFilter(s -> s.matches("[A-Za-z0-9_.]*"));
        batchBox = field(rx + 10, sizeY, halfW, "3", 3, String.valueOf(CommandSmithConfig.batchSize), s -> {
            try { CommandSmithConfig.batchSize = Math.max(1, Integer.parseInt(s)); } catch (NumberFormatException ignored) { }
        });
        batchBox.setFilter(s -> s.matches("\\d{0,3}"));
        delayBox = field(rx + 10 + halfW + 4, sizeY, halfW, "1", 6, AttrMod.format(CommandSmithConfig.delaySec), s -> {
            try { CommandSmithConfig.delaySec = Math.max(0, Double.parseDouble(s)); } catch (NumberFormatException ignored) { }
        });
        delayBox.setFilter(s -> s.matches("\\d{0,3}(\\.\\d{0,2})?"));
    }

    private EditBox field(int x, int y, int w, String hint, int max, String value, Consumer<String> onChange) {
        EditBox b = new EditBox(this.font, x + 4, y + 3, w - 8, 10, Component.literal(hint));
        b.setBordered(false);
        b.setMaxLength(max);
        b.setHint(Component.literal(hint));
        b.setValue(value);
        b.setResponder(onChange);
        this.addWidget(b);
        return b;
    }

    private void layout() {
        int pad = 8, gap = 6;
        top = pad + 26;
        bottom = this.height - pad;
        int avail = this.width - pad * 2 - gap * 2;
        lw = Math.max(140, Math.min(230, avail * 33 / 100));
        rw = Math.max(150, Math.min(260, avail * 34 / 100));
        midW = Math.max(130, avail - lw - rw);
        lx = pad;
        midX = lx + lw + gap;
        rx = midX + midW + gap;

        addY = bottom - 8 - 14;

        rankY = top + 18;
        recentY = top + 36;
        durLabelY = top + 74;
        durY = top + 84;
        durChipsY = top + 102;
        prevLabelY = top + 124;
        prevY = top + 134;
        addBtnY = bottom - 8 - 18;

        halfW = (rw - 20 - 4) / 2;
        sizeLabelY = top + 38;
        sizeY = top + 48;
        infoY = top + 68;
        queueLabelY = top + 82;
        queueTop = top + 94;
        startY = bottom - 8 - 18;
        clearY = startY - 4 - 14;
    }

    // ---- logic -------------------------------------------------------------
    private static int clamp(int v, int lo, int hi) { return Math.max(lo, Math.min(hi, v)); }

    private int count(Role r) {
        int n = 0;
        for (Member m : members) if (m.role == r) n++;
        return n;
    }

    private int countOn(Role r) {
        int n = 0;
        for (Member m : members) if (m.role == r && m.on) n++;
        return n;
    }

    private int onCount() {
        int n = 0;
        for (Member m : members) if (m.on) n++;
        return n;
    }

    private Member firstOn() {
        for (Member m : members) if (m.on) return m;
        return null;
    }

    private void setRole(Role r, boolean on) {
        for (Member m : members) if (m.role == r) m.on = on;
    }

    private void setAll(boolean on) {
        for (Member m : members) m.on = on;
    }

    private void scan() {
        List<String> lines = ChatHistory.lines(200);
        boolean[] sel = TeamParser.autoSelect(lines);
        List<String> chosen = new ArrayList<>();
        for (int i = 0; i < sel.length; i++) if (sel[i]) chosen.add(lines.get(i));
        List<Member> ms = TeamParser.parse(chosen);
        if (ms.isEmpty()) {
            say("No team info found. Run /team info, or use Pick lines.");
            return;
        }
        setMembers(ms);
        say("Found " + ms.size() + " players");
    }

    private void pick() {
        List<String> lines = ChatHistory.lines(120);
        this.minecraft.setScreen(new ChatPickerScreen(this, lines, TeamParser.autoSelect(lines)));
    }

    private void addManual() {
        String n = nameBox.getValue().trim();
        if (n.length() < 2) return;
        for (Member m : members) if (m.name.equalsIgnoreCase(n)) { say(n + " is already in the list"); return; }
        members.add(new Member(n, Role.OTHER));
        nameBox.setValue("");
        teamScroll = 1_000_000;
    }

    private List<String> recents() {
        List<String> out = new ArrayList<>();
        for (String s : CommandSmithConfig.recentRanks.split(",")) if (!s.isBlank()) out.add(s.trim());
        return out;
    }

    private void pushRecent(String rank) {
        List<String> r = new ArrayList<>(recents());
        r.removeIf(s -> s.equalsIgnoreCase(rank));
        r.add(0, rank);
        while (r.size() > 6) r.remove(r.size() - 1);
        CommandSmithConfig.recentRanks = String.join(",", r);
    }

    private void addToQueue() {
        String rank = CommandSmithConfig.rank.trim();
        String dur = CommandSmithConfig.duration.trim();
        if (rank.isEmpty()) { say("Type a rank first"); return; }
        if (dur.isEmpty()) { say("Type a duration, like 7d"); return; }
        int n = 0;
        for (Member m : members) {
            if (!m.on) continue;
            CommandQueue.add(m.name + "  " + rank + " " + dur, "lp user " + m.name + " parent addtemp " + rank + " " + dur);
            n++;
        }
        if (n == 0) { say("No names selected"); return; }
        pushRecent(rank);
        CommandSmithConfig.save();
        say("Added " + n + " to the queue");
    }

    private void toggleRun() {
        if (CommandQueue.running) { CommandQueue.pause(); return; }
        if (this.minecraft.player == null) { say("Join a world first"); return; }
        if (CommandQueue.pending() == 0) { say("The queue is empty"); return; }
        CommandQueue.start();
    }

    private void openGive() {
        gen.replay();
        this.minecraft.setScreen(gen);
    }

    @Override
    public void onClose() {
        CommandSmithConfig.save();
        this.minecraft.setScreen(this.parent);
    }

    // ---- input -------------------------------------------------------------
    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (event.button() == 0) {
            for (int i = hits.size() - 1; i >= 0; i--) {
                Hit h = hits.get(i);
                if (inside((int) event.x(), (int) event.y(), h.x, h.y, h.w, h.h)) {
                    this.setFocused(null);
                    h.action.run();
                    return true;
                }
            }
        }
        return super.mouseClicked(event, doubleClick);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        for (Zone z : zones) {
            if (inside((int) mouseX, (int) mouseY, z.x, z.y, z.w, z.h)) {
                z.onScroll.accept(scrollY > 0 ? 1 : -1);
                return true;
            }
        }
        return super.mouseScrolled(mouseX, mouseY, scrollX, scrollY);
    }

    // ---- render ------------------------------------------------------------
    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        Anim.frame();
        renderUi(g, mouseX, mouseY, delta);
        float p = Anim.ease(Anim.progress(openAt, 240));
        if (p < 1f) g.fill(0, 0, this.width, this.height, ((int) ((1f - p) * 255f)) << 24);
    }

    void renderUi(GuiGraphics g, int mouseX, int mouseY, float delta) {
        hits.clear();
        zones.clear();
        mxPos = mouseX;
        myPos = mouseY;
        batchBox.visible = CommandSmithConfig.queueMode == 1;
        delayBox.visible = CommandSmithConfig.queueMode != 0;

        g.fill(0, 0, this.width, this.height, BG);
        drawTitle(g);
        drawTeam(g, delta);
        drawCommand(g, delta);
        drawQueue(g, delta);
    }

    private void drawTitle(GuiGraphics g) {
        int x = 8, y = 8, w = this.width - 16, h = 22;
        g.fill(x, y, x + w, y + h, PANEL);
        border(g, x, y, w, h, BORDER);
        g.fill(x, y, x + 3, y + h, ACCENT);
        g.drawString(this.font, "COMMANDSMITH", x + 12, y + 7, TEXT, false);
        int tx0 = x + 12 + this.font.width("COMMANDSMITH") + 12;
        button(g, tx0, y + 2, 44, 18, "GIVE", false, false, this::openGive);
        button(g, tx0 + 48, y + 2, 52, 18, "RANKS", true, false, () -> { });
        button(g, x + w - 22, y + 2, 18, 18, "X", false, false, this::onClose);
        if (CommandQueue.running) {
            String t = "RUNNING " + CommandQueue.sent() + "/" + CommandQueue.ITEMS.size();
            g.drawString(this.font, t, x + w - 30 - this.font.width(t), y + 7, GOOD, false);
        }
    }

    private void drawTeam(GuiGraphics g, float delta) {
        panel(g, lx, top, lw, bottom - top);
        int ix = lx + 8, iw = lw - 16;
        int half = (iw - 2) / 2;
        button(g, ix, top + 8, half, 14, "Scan chat", false, true, this::scan);
        button(g, ix + half + 2, top + 8, iw - half - 2, 14, "Pick lines", false, false, this::pick);

        Role[] rs = {Role.OWNER, Role.ADMIN, Role.MEMBER};
        String[] names = {"Owner", "Admin", "Member"};
        int cw = (iw - 4) / 3;
        for (int i = 0; i < 3; i++) {
            Role r = rs[i];
            int cnt = count(r);
            boolean allOn = cnt > 0 && countOn(r) == cnt;
            button(g, ix + i * (cw + 2), top + 25, cw, 14, names[i] + " (" + cnt + ")", allOn, false, () -> setRole(r, !allOn));
        }
        button(g, ix, top + 42, half, 14, "All", false, false, () -> setAll(true));
        button(g, ix + half + 2, top + 42, iw - half - 2, 14, "None", false, false, () -> setAll(false));

        int ly = top + 60, lh = addY - 6 - ly, rowH = 16;
        if (lh > 0) {
            g.fill(ix, ly, ix + iw, ly + lh, PANEL2);
            border(g, ix, ly, iw, lh, BORDER);
            int content = members.size() * rowH;
            int maxScroll = Math.max(0, content - lh);
            teamScroll = clamp(teamScroll, 0, maxScroll);
            g.enableScissor(ix + 1, ly + 1, ix + iw - 1, ly + lh - 1);
            if (members.isEmpty()) {
                g.drawString(this.font, "No team loaded yet.", ix + 8, ly + 8, MUTED, false);
                g.drawString(this.font, "Run /team info in chat,", ix + 8, ly + 20, MUTED, false);
                g.drawString(this.font, "then press Scan chat.", ix + 8, ly + 30, MUTED, false);
            }
            for (int i = 0; i < members.size(); i++) {
                int ry = ly + i * rowH - teamScroll;
                if (ry + rowH <= ly) continue;
                if (ry >= ly + lh) break;
                Member m = members.get(i);
                int cy1 = Math.max(ry, ly), cy2 = Math.min(ry + rowH, ly + lh);
                boolean hov = inside(mxPos, myPos, ix, cy1, iw - 20, cy2 - cy1);
                float t = hover.t(1000 + i, hov);
                if (t > 0f) g.fill(ix + 1, ry, ix + iw - 1, ry + rowH, Anim.mix(PANEL2, HOVER, t));
                // checkbox
                g.fill(ix + 8, ry + 3, ix + 18, ry + 13, PANEL);
                border(g, ix + 8, ry + 3, 10, 10, m.on ? ACCENT : BORDER);
                if (m.on) g.fill(ix + 10, ry + 5, ix + 16, ry + 11, ACCENT);
                // name + role
                String tag = m.role.label;
                int tagW = this.font.width(tag);
                int tagColor = m.role == Role.OWNER ? 0xFFFFAA00 : m.role == Role.ADMIN ? ENCH : m.role == Role.MEMBER ? GOOD : MUTED;
                g.drawString(this.font, fit(m.name, iw - 28 - tagW - 28), ix + 24, ry + 4, m.on ? TEXT : MUTED, false);
                g.drawString(this.font, tag, ix + iw - 22 - tagW, ry + 4, tagColor, false);
                hits.add(new Hit(ix, cy1, iw - 20, cy2 - cy1, () -> m.on = !m.on));
                // remove
                int rx2 = ix + iw - 16;
                int ry1 = Math.max(ry + 2, ly), ry2 = Math.min(ry + 14, ly + lh);
                boolean hovX = ry2 > ry1 && inside(mxPos, myPos, rx2, ry1, 12, ry2 - ry1);
                g.fill(rx2, ry + 2, rx2 + 12, ry + 14, hovX ? ACCENT_DIM : PANEL);
                border(g, rx2, ry + 2, 12, 12, hovX ? ACCENT : BORDER);
                g.drawString(this.font, "x", rx2 + 4, ry + 4, MUTED, false);
                if (ry2 > ry1) hits.add(new Hit(rx2, ry1, 12, ry2 - ry1, () -> members.remove(m)));
            }
            g.disableScissor();
            scrollbar(g, ix + iw - 3, ly + 1, lh - 2, content, teamScroll);
            zones.add(new Zone(ix, ly, iw, lh, d -> teamScroll = clamp(teamScroll - d * rowH * 2, 0, maxScroll)));
        }

        fieldBg(g, ix, addY, iw - 22, 14, nameBox);
        nameBox.render(g, mxPos, myPos, delta);
        button(g, ix + iw - 20, addY, 20, 14, "+", false, false, this::addManual);
    }

    private void drawCommand(GuiGraphics g, float delta) {
        panel(g, midX, top, midW, bottom - top);
        int ix = midX + 10, iw = midW - 20;

        label(g, "RANK", ix, top + 8);
        fieldBg(g, ix, rankY, iw, 14, rankBox);
        rankBox.render(g, mxPos, myPos, delta);

        int cx = ix, cy = recentY;
        for (String r : recents()) {
            int w = Math.min(iw, this.font.width(r) + 10);
            if (cx + w > ix + iw) { cx = ix; cy += 17; }
            if (cy > recentY + 17) break;
            button(g, cx, cy, w, 14, r, r.equalsIgnoreCase(CommandSmithConfig.rank.trim()), false,
                () -> { rankBox.setValue(r); CommandSmithConfig.rank = r; });
            cx += w + 3;
        }

        label(g, "DURATION", ix, durLabelY);
        fieldBg(g, ix, durY, iw, 14, durBox);
        durBox.render(g, mxPos, myPos, delta);
        int dw = (iw - (DURATIONS.length - 1) * 2) / DURATIONS.length;
        for (int i = 0; i < DURATIONS.length; i++) {
            String d = DURATIONS[i];
            button(g, ix + i * (dw + 2), durChipsY, dw, 14, d, d.equalsIgnoreCase(CommandSmithConfig.duration.trim()), false,
                () -> { durBox.setValue(d); CommandSmithConfig.duration = d; });
        }

        label(g, "PREVIEW", ix, prevLabelY);
        int ph = Math.max(20, addBtnY - 16 - prevY);
        g.fill(ix, prevY, ix + iw, prevY + ph, 0xFF0D1017);
        border(g, ix, prevY, iw, ph, BORDER);
        Member first = firstOn();
        String rank = CommandSmithConfig.rank.trim().isEmpty() ? "<rank>" : CommandSmithConfig.rank.trim();
        String dur = CommandSmithConfig.duration.trim().isEmpty() ? "<time>" : CommandSmithConfig.duration.trim();
        String prev = "/lp user " + (first == null ? "<ign>" : first.name) + " parent addtemp " + rank + " " + dur;
        int py = prevY + 5;
        for (String line : wrap(prev, iw - 10)) {
            if (py + 9 > prevY + ph) break;
            g.drawString(this.font, line, ix + 5, py, 0xFFBFC8E0, false);
            py += 10;
        }

        if (System.currentTimeMillis() < statusUntil) {
            g.drawString(this.font, fit(status, iw), ix, addBtnY - 12, GOOD, false);
        }
        int n = onCount();
        if (n > 0) button(g, ix, addBtnY, iw, 18, "ADD TO QUEUE (" + n + ")", false, true, this::addToQueue);
        else disabledButton(g, ix, addBtnY, iw, 18, "ADD TO QUEUE (0)");
    }

    private void drawQueue(GuiGraphics g, float delta) {
        panel(g, rx, top, rw, bottom - top);
        int ix = rx + 10, iw = rw - 20;
        int mode = CommandSmithConfig.queueMode;

        label(g, "RUN MODE", ix, top + 8);
        String[] modes = {"All at once", "Batches", "One by one"};
        int mw = (iw - 4) / 3;
        for (int i = 0; i < 3; i++) {
            int idx = i;
            button(g, ix + i * (mw + 2), top + 18, mw, 14, modes[i], mode == i, false, () -> { CommandSmithConfig.queueMode = idx; CommandSmithConfig.save(); });
        }

        if (mode == 0) {
            g.drawString(this.font, "Sends everything at the same instant.", ix, sizeLabelY, MUTED, false);
            if (CommandQueue.pending() > 8) g.drawString(this.font, "Big teams can trip spam kicks.", ix, sizeLabelY + 10, 0xFFC9A227, false);
        } else {
            label(g, mode == 1 ? "BATCH SIZE" : "ONE AT A TIME", ix, sizeLabelY);
            label(g, "DELAY (sec)", ix + halfW + 4, sizeLabelY);
            if (mode == 1) {
                fieldBg(g, ix, sizeY, halfW, 14, batchBox);
                batchBox.render(g, mxPos, myPos, delta);
            }
            fieldBg(g, ix + halfW + 4, sizeY, halfW, 14, delayBox);
            delayBox.render(g, mxPos, myPos, delta);
        }

        int p = CommandQueue.pending();
        String est;
        if (mode == 0) est = p + " pending - all go at once";
        else {
            int per = mode == 1 ? Math.max(1, CommandSmithConfig.batchSize) : 1;
            int batches = (p + per - 1) / per;
            double secs = Math.max(0, batches - 1) * Math.max(0, CommandSmithConfig.delaySec);
            est = p + " pending - about " + AttrMod.format(secs) + "s";
        }
        g.drawString(this.font, fit(est, iw), ix, infoY, ENCH, false);

        String ql = "QUEUE  (" + CommandQueue.sent() + "/" + CommandQueue.ITEMS.size() + " sent)";
        label(g, ql, ix, queueLabelY);

        int ly = queueTop, lh = clearY - 6 - ly, rowH = 13;
        if (lh > 0) {
            g.fill(ix, ly, ix + iw, ly + lh, PANEL2);
            border(g, ix, ly, iw, lh, BORDER);
            int total = CommandQueue.ITEMS.size();
            if (total > 0) {
                int barW = (int) ((iw - 2) * (CommandQueue.sent() / (float) total));
                g.fill(ix + 1, ly + lh - 2, ix + 1 + barW, ly + lh - 1, GOOD);
            }
            int content = total * rowH;
            int maxScroll = Math.max(0, content - lh);
            queueScroll = clamp(queueScroll, 0, maxScroll);
            g.enableScissor(ix + 1, ly + 1, ix + iw - 1, ly + lh - 1);
            if (total == 0) {
                g.drawString(this.font, "Queue is empty.", ix + 8, ly + 8, MUTED, false);
                g.drawString(this.font, "Add names from the middle.", ix + 8, ly + 20, MUTED, false);
            }
            for (int i = 0; i < total; i++) {
                int ry = ly + i * rowH - queueScroll;
                if (ry + rowH <= ly) continue;
                if (ry >= ly + lh) break;
                CommandQueue.Item it = CommandQueue.ITEMS.get(i);
                if (it.sent) g.fill(ix + 6, ry + 4, ix + 11, ry + 9, GOOD);
                else border(g, ix + 6, ry + 4, 5, 5, MUTED);
                g.drawString(this.font, fit(it.label, iw - 24), ix + 16, ry + 3, it.sent ? MUTED : TEXT, false);
            }
            g.disableScissor();
            scrollbar(g, ix + iw - 3, ly + 1, lh - 2, content, queueScroll);
            zones.add(new Zone(ix, ly, iw, lh, d -> queueScroll = clamp(queueScroll - d * rowH * 2, 0, maxScroll)));
        }

        int half = (iw - 2) / 2;
        button(g, ix, clearY, half, 14, "Clear sent", false, false, CommandQueue::clearSent);
        button(g, ix + half + 2, clearY, iw - half - 2, 14, "Clear all", false, false, CommandQueue::clearAll);
        boolean run = CommandQueue.running;
        String label = run ? "PAUSE" : (p > 0 ? "START (" + p + ")" : "START");
        if (run || p > 0) button(g, ix, startY, iw, 18, label, run, true, this::toggleRun);
        else disabledButton(g, ix, startY, iw, 18, label);
    }

    // ---- helpers -------------------------------------------------------------
    private void button(GuiGraphics g, int x, int y, int w, int h, String label, boolean active, boolean primary, Runnable r) {
        boolean hov = inside(mxPos, myPos, x, y, w, h);
        float ht = hover.t(x * 31 + y * 17 + w, hov);
        int bg = primary ? Anim.mix(ACCENT, 0xFF8279FF, ht) : active ? Anim.mix(ACCENT_DIM, 0xFF38337F, ht) : Anim.mix(PANEL2, HOVER, ht);
        int bd = primary || active ? ACCENT : Anim.mix(BORDER, 0xFF4A5372, ht);
        g.fill(x, y, x + w, y + h, bg);
        border(g, x, y, w, h, bd);
        String l = fit(label, w - 4);
        g.drawString(this.font, l, x + (w - this.font.width(l)) / 2, y + (h - 8) / 2 + 1,
            primary ? 0xFFFFFFFF : active ? TEXT : 0xFFB4BCD0, false);
        hits.add(new Hit(x, y, w, h, r));
    }

    private void disabledButton(GuiGraphics g, int x, int y, int w, int h, String label) {
        g.fill(x, y, x + w, y + h, PANEL);
        border(g, x, y, w, h, BORDER);
        String l = fit(label, w - 4);
        g.drawString(this.font, l, x + (w - this.font.width(l)) / 2, y + (h - 8) / 2 + 1, 0xFF4B5268, false);
    }

    private void panel(GuiGraphics g, int x, int y, int w, int h) {
        g.fill(x, y, x + w, y + h, PANEL);
        border(g, x, y, w, h, BORDER);
    }

    private void fieldBg(GuiGraphics g, int x, int y, int w, int h, EditBox box) {
        g.fill(x, y, x + w, y + h, PANEL2);
        border(g, x, y, w, h, box != null && box.isFocused() ? ACCENT : BORDER);
    }

    private void border(GuiGraphics g, int x, int y, int w, int h, int c) {
        g.fill(x, y, x + w, y + 1, c);
        g.fill(x, y + h - 1, x + w, y + h, c);
        g.fill(x, y, x + 1, y + h, c);
        g.fill(x + w - 1, y, x + w, y + h, c);
    }

    private void label(GuiGraphics g, String s, int x, int y) {
        g.drawString(this.font, s, x, y, MUTED, false);
    }

    private void scrollbar(GuiGraphics g, int x, int y, int h, int content, int scroll) {
        if (content <= h) return;
        int thumb = Math.max(12, h * h / content);
        int ty = y + (int) ((long) (h - thumb) * scroll / (content - h));
        g.fill(x, ty, x + 2, ty + thumb, 0xFF4A5372);
    }

    private static boolean inside(int px, int py, int x, int y, int w, int h) {
        return px >= x && px < x + w && py >= y && py < y + h;
    }

    private String fit(String s, int maxW) {
        if (maxW <= 0) return "";
        if (this.font.width(s) <= maxW) return s;
        while (!s.isEmpty() && this.font.width(s + "..") > maxW) s = s.substring(0, s.length() - 1);
        return s + "..";
    }

    private List<String> wrap(String s, int maxW) {
        List<String> out = new ArrayList<>();
        StringBuilder line = new StringBuilder();
        for (char c : s.toCharArray()) {
            if (this.font.width(line.toString() + c) > maxW && line.length() > 0) {
                out.add(line.toString());
                line.setLength(0);
            }
            line.append(c);
        }
        if (line.length() > 0) out.add(line.toString());
        return out;
    }
}
