package dev.commandsmith.gui;

import dev.commandsmith.data.StyledText;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import java.util.List;

/** Draws a StyledText character by character so gradients show up in the GUI. */
final class StyledRender {
    private StyledRender() {}

    private static Component piece(String ch, StyledText st) {
        return Component.literal(ch).withStyle(s -> s
            .withBold(st.bold).withItalic(st.italic)
            .withUnderlined(st.underline).withStrikethrough(st.strike)
            .withObfuscated(st.obfuscated));
    }

    static int width(Font font, StyledText st) {
        int w = 0;
        for (String ch : st.chars()) w += font.width(piece(ch, st));
        return w;
    }

    static void draw(GuiGraphics g, Font font, StyledText st, int x, int y, int maxW) {
        List<String> chars = st.chars();
        int n = chars.size(), cx = x;
        for (int i = 0; i < n; i++) {
            Component c = piece(chars.get(i), st);
            int w = font.width(c);
            if (cx + w > x + maxW) break;
            int rgb = st.colorAt(i, n);
            if (rgb == 0) rgb = 0x3A3A3A; // pure black is invisible on the dark UI
            g.drawString(font, c, cx, y, 0xFF000000 | rgb, false);
            cx += w;
        }
    }

    static void drawScaled(GuiGraphics g, Font font, StyledText st, int x, int y, int maxW, int scale) {
        var pose = g.pose();
        pose.pushMatrix();
        pose.translate((float) x, (float) y);
        pose.scale((float) scale, (float) scale);
        draw(g, font, st, 0, 0, maxW / scale);
        pose.popMatrix();
    }
}
