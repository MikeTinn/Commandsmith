package dev.commandsmith.gui;

import dev.commandsmith.data.CommandBuilder;
import dev.commandsmith.data.StyledText;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.IntConsumer;

/**
 * Birdflop-style text editor (gradient colours + formatting) that opens on top of the generator.
 * Used for the item name (one text) and the lore (many lines, each with its own style).
 */
public class TextEditorScreen extends Screen {
    public enum Mode { NAME, LORE }

    private static final int BG_PANEL = GeneratorScreen.PANEL, PANEL2 = GeneratorScreen.PANEL2;
    private static final int BORDER = GeneratorScreen.BORDER, ACCENT = GeneratorScreen.ACCENT;
    private static final int ACCENT_DIM = GeneratorScreen.ACCENT_DIM, TEXT = GeneratorScreen.TEXT;
    private static final int MUTED = GeneratorScreen.MUTED, HOVER = GeneratorScreen.HOVER;
    private static final int LORE_DEFAULT = 0xAAAAAA;

    private static final String[] PRESET_NAMES = {"Rainbow", "Fire", "Ocean", "Sunset", "Mint", "Pastel"};
    private static final int[][] PRESET_COLORS = {
        {0xFF5555, 0xFFAA00, 0xFFFF55, 0x55FF55, 0x55FFFF, 0x5555FF, 0xAA55FF},
        {0xFF0000, 0xFF7A00, 0xFFD000},
        {0x0066FF, 0x00D4FF, 0x00FFC8},
        {0xFF5F6D, 0xFFC371},
        {0x00B09B, 0x96C93D},
        {0xFFB3D9, 0xC9B3FF, 0xB3E5FF}
    };

    private record Hit(int x, int y, int w, int h, Runnable action) {}
    private record Zone(int x, int y, int w, int h, IntConsumer onScroll) {}

    private final GeneratorScreen parent;
    private final Mode mode;
    private final CommandBuilder cmd;

    private int selLine = 0, selStop = 0, lineScroll = 0;
    private float hue = 0f, sat = 1f, val = 1f;
    private boolean suppress;
    private int dragMode; // 0 none, 1 saturation/value square, 2 hue bar

    private EditBox textBox, hexBox;
    private final List<Hit> hits = new ArrayList<>();
    private final List<Zone> zones = new ArrayList<>();
    private int mxPos, myPos;

    // layout
    private int ox, oy, ow, oh, ct, cb, lx2, lw2, rx2, rw2;
    private int textY, prevLabelY, prevY, prevH;
    private int listY, listH, lineBtnY, textLabelY;
    private int stopsY, pickX, pickY, pickW, pickH, hueX, rightX, rightW, hexY;
    private int fmtLabelY, fmtY, extraY;

    public TextEditorScreen(GeneratorScreen parent, Mode mode, CommandBuilder cmd) {
        super(Component.literal(mode == Mode.NAME ? "Edit name" : "Edit lore"));
        this.parent = parent;
        this.mode = mode;
        this.cmd = cmd;
        if (mode == Mode.LORE && cmd.lore.isEmpty()) cmd.lore.add(new StyledText(LORE_DEFAULT));
    }

    private StyledText current() {
        return mode == Mode.NAME ? cmd.name : cmd.lore.get(selLine);
    }

    // ---- setup -------------------------------------------------------------
    @Override
    protected void init() {
        parent.resize(this.minecraft, this.width, this.height); // keep the backdrop in sync with window size
        layout();
        textBox = field(lx2, textY, lw2, "Type your text...", 150, current().text, s -> { if (!suppress) current().text = s; });
        hexBox = field(rightX, hexY, Math.min(72, rightW), "#RRGGBB", 7, "", this::onHex);
        hexBox.setFilter(s -> s.matches("#?[0-9a-fA-F]{0,6}"));
        loadStop();
        this.setFocused(textBox);
        textBox.setFocused(true);
    }

    private EditBox field(int x, int y, int w, String hint, int max, String value, Consumer<String> onChange) {
        EditBox b = new EditBox(this.font, x + 4, y + 3, w - 8, 10, Component.literal(hint));
        b.setBordered(false);
        b.setMaxLength(max);
        b.setHint(Component.literal(hint));
        b.setValue(value);
        b.setResponder(onChange);
        this.addWidget(b);
        return b;
    }

    private void layout() {
        ow = Math.min(470, this.width - 16);
        oh = Math.min(256, this.height - 16);
        ox = (this.width - ow) / 2;
        oy = (this.height - oh) / 2;
        ct = oy + 30;
        cb = oy + oh - 30;
        lx2 = ox + 10;
        lw2 = (ow - 30) * 44 / 100;
        rx2 = lx2 + lw2 + 10;
        rw2 = ox + ow - 10 - rx2;

        if (mode == Mode.NAME) {
            textY = ct + 10;
            prevLabelY = ct + 34;
            prevY = ct + 44;
        } else {
            listY = ct + 10;
            listH = 70;
            lineBtnY = listY + listH + 4;
            textLabelY = lineBtnY + 20;
            textY = textLabelY + 10;
            prevLabelY = textY + 20;
            prevY = prevLabelY + 10;
        }
        prevH = cb - 6 - prevY;

        stopsY = ct + 10;
        pickX = rx2;
        pickY = ct + 36;
        pickW = clamp(rw2 / 2 - 20, 60, 100);
        pickH = 72;
        hueX = pickX + pickW + 6;
        rightX = hueX + 10 + 8;
        rightW = rx2 + rw2 - rightX;
        hexY = pickY + 10;
        fmtLabelY = pickY + pickH + 8;
        fmtY = fmtLabelY + 10;
        extraY = fmtY + 34;
    }

    // ---- logic -------------------------------------------------------------
    private static int clamp(int v, int lo, int hi) { return Math.max(lo, Math.min(hi, v)); }
    private static float clamp01(float v) { return Math.max(0f, Math.min(1f, v)); }

    static int hsvToRgb(float h, float s, float v) {
        float c = v * s;
        float hh = (h % 360f) / 60f;
        float x = c * (1 - Math.abs(hh % 2 - 1));
        float m = v - c;
        float r, g, b;
        switch ((int) hh) {
            case 0: r = c; g = x; b = 0; break;
            case 1: r = x; g = c; b = 0; break;
            case 2: r = 0; g = c; b = x; break;
            case 3: r = 0; g = x; b = c; break;
            case 4: r = x; g = 0; b = c; break;
            default: r = c; g = 0; b = x; break;
        }
        return (Math.round((r + m) * 255) << 16) | (Math.round((g + m) * 255) << 8) | Math.round((b + m) * 255);
    }

    static float[] rgbToHsv(int rgb) {
        float r = ((rgb >> 16) & 255) / 255f, g = ((rgb >> 8) & 255) / 255f, b = (rgb & 255) / 255f;
        float max = Math.max(r, Math.max(g, b)), min = Math.min(r, Math.min(g, b)), d = max - min;
        float h;
        if (d == 0) h = 0;
        else if (max == r) h = ((g - b) / d) % 6;
        else if (max == g) h = (b - r) / d + 2;
        else h = (r - g) / d + 4;
        h *= 60f;
        if (h < 0) h += 360f;
        return new float[] {h, max == 0 ? 0 : d / max, max};
    }

    private void loadStop() {
        selStop = clamp(selStop, 0, current().stops.size() - 1);
        int rgb = current().stops.get(selStop);
        float[] hsv = rgbToHsv(rgb);
        if (hsv[1] > 0.01f && hsv[2] > 0.01f) hue = hsv[0];
        sat = hsv[1];
        val = hsv[2];
        suppress = true;
        hexBox.setValue(String.format("#%06x", rgb));
        suppress = false;
    }

    private void applyHsv() {
        int rgb = hsvToRgb(hue, sat, val);
        current().stops.set(selStop, rgb);
        suppress = true;
        hexBox.setValue(String.format("#%06x", rgb));
        suppress = false;
    }

    private void onHex(String s) {
        if (suppress) return;
        String h = s.startsWith("#") ? s.substring(1) : s;
        if (h.length() != 6) return;
        try {
            int rgb = Integer.parseInt(h, 16);
            current().stops.set(selStop, rgb);
            float[] hsv = rgbToHsv(rgb);
            if (hsv[1] > 0.01f && hsv[2] > 0.01f) hue = hsv[0];
            sat = hsv[1];
            val = hsv[2];
        } catch (NumberFormatException ignored) {
        }
    }

    private void selectLine(int i) {
        selLine = clamp(i, 0, cmd.lore.size() - 1);
        selStop = 0;
        suppress = true;
        textBox.setValue(current().text);
        suppress = false;
        loadStop();
    }

    private void addStop() {
        List<Integer> st = current().stops;
        if (st.size() >= 8) return;
        st.add(hsvToRgb((hue + 50f) % 360f, Math.max(sat, 0.6f), Math.max(val, 0.9f)));
        selStop = st.size() - 1;
        loadStop();
    }

    private void removeStop() {
        List<Integer> st = current().stops;
        if (st.size() <= 1) return;
        st.remove(selStop);
        selStop = clamp(selStop, 0, st.size() - 1);
        loadStop();
    }

    private void preset(int[] colors) {
        List<Integer> st = current().stops;
        st.clear();
        for (int c : colors) st.add(c);
        selStop = 0;
        loadStop();
    }

    private void reverse() {
        Collections.reverse(current().stops);
        selStop = current().stops.size() - 1 - selStop;
        loadStop();
    }

    private void moveLine(int dir) {
        int j = selLine + dir;
        if (j < 0 || j >= cmd.lore.size()) return;
        Collections.swap(cmd.lore, selLine, j);
        selLine = j;
    }

    private void addLine() {
        StyledText n = current().copy();
        n.text = "";
        cmd.lore.add(selLine + 1, n);
        selectLine(selLine + 1);
    }

    private void deleteLine() {
        if (cmd.lore.size() <= 1) {
            cmd.lore.get(0).text = "";
            selectLine(0);
            return;
        }
        cmd.lore.remove(selLine);
        selectLine(Math.min(selLine, cmd.lore.size() - 1));
    }

    private void applyToAll() {
        StyledText cur = current();
        for (StyledText l : cmd.lore) if (l != cur) l.copyStyleFrom(cur);
    }

    @Override
    public void onClose() {
        this.minecraft.setScreen(this.parent);
    }

    // ---- input -------------------------------------------------------------
    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (event.button() == 0) {
            int mx = (int) event.x(), my = (int) event.y();
            for (int i = hits.size() - 1; i >= 0; i--) {
                Hit h = hits.get(i);
                if (inside(mx, my, h.x, h.y, h.w, h.h)) {
                    this.setFocused(null);
                    h.action.run();
                    return true;
                }
            }
            if (inside(mx, my, pickX, pickY, pickW, pickH)) { dragMode = 1; drag(mx, my); this.setFocused(null); return true; }
            if (inside(mx, my, hueX, pickY, 10, pickH)) { dragMode = 2; drag(mx, my); this.setFocused(null); return true; }
        }
        return super.mouseClicked(event, doubleClick);
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dx, double dy) {
        if (dragMode != 0) {
            drag((int) event.x(), (int) event.y());
            return true;
        }
        return super.mouseDragged(event, dx, dy);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        dragMode = 0;
        return super.mouseReleased(event);
    }

    private void drag(int mx, int my) {
        if (dragMode == 1) {
            sat = clamp01((mx - pickX) / (float) (pickW - 1));
            val = 1f - clamp01((my - pickY) / (float) (pickH - 1));
        } else if (dragMode == 2) {
            hue = clamp01((my - pickY) / (float) (pickH - 1)) * 359.9f;
        }
        applyHsv();
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        for (Zone z : zones) {
            if (inside((int) mouseX, (int) mouseY, z.x, z.y, z.w, z.h)) {
                z.onScroll.accept(scrollY > 0 ? 1 : -1);
                return true;
            }
        }
        return super.mouseScrolled(mouseX, mouseY, scrollX, scrollY);
    }

    // ---- render ------------------------------------------------------------
    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        hits.clear();
        zones.clear();
        mxPos = mouseX;
        myPos = mouseY;

        parent.renderUi(g, -10000, -10000, delta); // the generator stays visible underneath
        g.fill(0, 0, this.width, this.height, 0xC8000000);
        g.fill(ox, oy, ox + ow, oy + oh, BG_PANEL);
        border(g, ox, oy, ow, oh, BORDER);

        // header
        g.fill(ox, oy, ox + ow, oy + 22, PANEL2);
        g.fill(ox, oy + 22, ox + ow, oy + 23, BORDER);
        g.fill(ox, oy, ox + 3, oy + 22, ACCENT);
        String title = mode == Mode.NAME ? "EDIT NAME" : "EDIT LORE";
        g.drawString(this.font, title, ox + 12, oy + 7, TEXT, false);
        g.drawString(this.font, "gradient + formatting", ox + 12 + this.font.width(title) + 8, oy + 7, MUTED, false);
        button(g, ox + ow - 22, oy + 2, 18, 18, "X", false, false, this::onClose);

        drawLeft(g, delta);
        drawRight(g, delta);

        // footer
        int fy = oy + oh - 10 - 18;
        g.drawString(this.font, current().text.codePointCount(0, current().text.length()) + " chars", ox + 10, fy + 5, MUTED, false);
        button(g, ox + ow - 10 - 90, fy, 90, 18, "DONE", false, true, this::onClose);
    }

    private void drawLeft(GuiGraphics g, float delta) {
        if (mode == Mode.NAME) {
            label(g, "TEXT", lx2, ct);
            fieldBg(g, lx2, textY, lw2, 14, textBox);
            textBox.render(g, mxPos, myPos, delta);
            label(g, "PREVIEW", lx2, prevLabelY);
            drawPreview(g, lx2, prevY, lw2, prevH);
            return;
        }

        label(g, "LINES  (" + cmd.lore.size() + ")", lx2, ct);
        g.fill(lx2, listY, lx2 + lw2, listY + listH, PANEL2);
        border(g, lx2, listY, lw2, listH, BORDER);
        int rowH = 14, content = cmd.lore.size() * rowH;
        int maxScroll = Math.max(0, content - (listH - 2));
        lineScroll = clamp(lineScroll, 0, maxScroll);
        g.enableScissor(lx2 + 1, listY + 1, lx2 + lw2 - 1, listY + listH - 1);
        for (int i = 0; i < cmd.lore.size(); i++) {
            int ry = listY + 1 + i * rowH - lineScroll;
            if (ry + rowH <= listY) continue;
            if (ry >= listY + listH) break;
            boolean sel = i == selLine;
            int cy1 = Math.max(ry, listY + 1), cy2 = Math.min(ry + rowH, listY + listH - 1);
            boolean hov = cy2 > cy1 && inside(mxPos, myPos, lx2 + 1, cy1, lw2 - 2, cy2 - cy1);
            if (sel) { g.fill(lx2 + 1, ry, lx2 + lw2 - 1, ry + rowH, ACCENT_DIM); g.fill(lx2 + 1, ry, lx2 + 3, ry + rowH, ACCENT); }
            else if (hov) g.fill(lx2 + 1, ry, lx2 + lw2 - 1, ry + rowH, HOVER);
            g.drawString(this.font, String.valueOf(i + 1), lx2 + 7, ry + 3, MUTED, false);
            StyledText l = cmd.lore.get(i);
            if (l.text.isEmpty()) g.drawString(this.font, "(empty)", lx2 + 22, ry + 3, 0xFF4B5268, false);
            else StyledRender.draw(g, this.font, l, lx2 + 22, ry + 3, lw2 - 30);
            final int idx = i;
            if (cy2 > cy1) hits.add(new Hit(lx2 + 1, cy1, lw2 - 2, cy2 - cy1, () -> selectLine(idx)));
        }
        g.disableScissor();
        scrollbar(g, lx2 + lw2 - 3, listY + 1, listH - 2, content, lineScroll);
        zones.add(new Zone(lx2, listY, lw2, listH, d -> lineScroll = clamp(lineScroll - d * rowH, 0, maxScroll)));

        int bw = (lw2 - 6) / 4;
        button(g, lx2, lineBtnY, bw, 14, "Add", false, false, this::addLine);
        button(g, lx2 + (bw + 2), lineBtnY, bw, 14, "Del", false, false, this::deleteLine);
        button(g, lx2 + 2 * (bw + 2), lineBtnY, bw, 14, "Up", false, false, () -> moveLine(-1));
        button(g, lx2 + 3 * (bw + 2), lineBtnY, bw, 14, "Down", false, false, () -> moveLine(1));

        label(g, "TEXT  (line " + (selLine + 1) + ")", lx2, textLabelY);
        fieldBg(g, lx2, textY, lw2, 14, textBox);
        textBox.render(g, mxPos, myPos, delta);
        label(g, "PREVIEW", lx2, prevLabelY);
        drawPreview(g, lx2, prevY, lw2, prevH);
    }

    private void drawPreview(GuiGraphics g, int x, int y, int w, int h) {
        if (h < 16) return;
        g.fill(x, y, x + w, y + h, 0xF0100010); // vanilla tooltip look
        border(g, x, y, w, h, 0xFF3B1B78);
        if (mode == Mode.NAME) {
            StyledText st = cmd.name;
            if (st.text.isEmpty()) {
                g.drawString(this.font, "Your text here", x + 8, y + 8, MUTED, false);
                return;
            }
            int scale = StyledRender.width(this.font, st) * 2 <= w - 16 ? 2 : 1;
            StyledRender.drawScaled(g, this.font, st, x + 8, y + 8, w - 16, scale);
        } else {
            int ly = y + 8;
            for (StyledText l : cmd.lore) {
                if (ly + 9 > y + h) break;
                StyledRender.draw(g, this.font, l, x + 8, ly, w - 16);
                ly += 10;
            }
        }
    }

    private void drawRight(GuiGraphics g, float delta) {
        StyledText cur = current();

        label(g, "GRADIENT COLORS  (" + cur.stops.size() + ")", rx2, ct);
        int n = cur.stops.size();
        for (int i = 0; i < n; i++) {
            int sx = rx2 + i * 21;
            final int idx = i;
            g.fill(sx, stopsY, sx + 18, stopsY + 18, 0xFF000000 | cur.stops.get(i));
            border(g, sx, stopsY, 18, 18, i == selStop ? 0xFFFFFFFF : inside(mxPos, myPos, sx, stopsY, 18, 18) ? MUTED : BORDER);
            hits.add(new Hit(sx, stopsY, 18, 18, () -> { selStop = idx; loadStop(); }));
        }
        int bx = rx2 + n * 21;
        if (n < 8) { button(g, bx, stopsY, 18, 18, "+", false, false, this::addStop); bx += 21; }
        if (n > 1) button(g, bx, stopsY, 18, 18, "-", false, false, this::removeStop);

        // saturation / value square
        int cols = Math.max(2, pickW / 4), rows = Math.max(2, pickH / 4);
        for (int c = 0; c < cols; c++) {
            int x1 = pickX + c * pickW / cols, x2 = pickX + (c + 1) * pickW / cols;
            for (int r = 0; r < rows; r++) {
                int y1 = pickY + r * pickH / rows, y2 = pickY + (r + 1) * pickH / rows;
                g.fill(x1, y1, x2, y2, 0xFF000000 | hsvToRgb(hue, c / (cols - 1f), 1f - r / (rows - 1f)));
            }
        }
        border(g, pickX, pickY, pickW, pickH, BORDER);
        int mx = pickX + Math.round(sat * (pickW - 1)), my = pickY + Math.round((1f - val) * (pickH - 1));
        border(g, mx - 3, my - 3, 7, 7, 0xFFFFFFFF);
        border(g, mx - 2, my - 2, 5, 5, 0xFF000000);

        // hue bar
        int hrows = Math.max(2, pickH / 2);
        for (int r = 0; r < hrows; r++) {
            int y1 = pickY + r * pickH / hrows, y2 = pickY + (r + 1) * pickH / hrows;
            g.fill(hueX, y1, hueX + 10, y2, 0xFF000000 | hsvToRgb(r / (hrows - 1f) * 359.9f, 1f, 1f));
        }
        border(g, hueX, pickY, 10, pickH, BORDER);
        int hy = pickY + Math.round(hue / 359.9f * (pickH - 1));
        g.fill(hueX - 2, hy - 1, hueX + 12, hy + 1, 0xFFFFFFFF);

        // hex + presets
        label(g, "HEX", rightX, pickY);
        int hw = Math.min(72, rightW);
        fieldBg(g, rightX, hexY, hw, 14, hexBox);
        hexBox.render(g, mxPos, myPos, delta);
        int colW = (rightW - 2) / 2;
        for (int i = 0; i < PRESET_NAMES.length; i++) {
            int px = rightX + (i % 2) * (colW + 2), py = pickY + 28 + (i / 2) * 17;
            final int[] cols2 = PRESET_COLORS[i];
            button(g, px, py, colW, 14, PRESET_NAMES[i], false, false, () -> preset(cols2));
        }

        // formatting
        label(g, "FORMAT", rx2, fmtLabelY);
        int tw = (rw2 - 6) / 3;
        button(g, rx2, fmtY, tw, 14, "Bold", cur.bold, false, () -> cur.bold = !cur.bold);
        button(g, rx2 + tw + 3, fmtY, tw, 14, "Italic", cur.italic, false, () -> cur.italic = !cur.italic);
        button(g, rx2 + 2 * (tw + 3), fmtY, tw, 14, "Underline", cur.underline, false, () -> cur.underline = !cur.underline);
        int tw2 = (rw2 - 3) / 2;
        button(g, rx2, fmtY + 17, tw2, 14, "Strikethrough", cur.strike, false, () -> cur.strike = !cur.strike);
        button(g, rx2 + tw2 + 3, fmtY + 17, tw2, 14, "Obfuscated", cur.obfuscated, false, () -> cur.obfuscated = !cur.obfuscated);

        if (mode == Mode.LORE) {
            button(g, rx2, extraY, tw2, 14, "Reverse colors", false, false, this::reverse);
            button(g, rx2 + tw2 + 3, extraY, tw2, 14, "Style to all lines", false, false, this::applyToAll);
        } else {
            button(g, rx2, extraY, tw2, 14, "Reverse colors", false, false, this::reverse);
        }
    }

    // ---- helpers -------------------------------------------------------------
    private void button(GuiGraphics g, int x, int y, int w, int h, String label, boolean active, boolean primary, Runnable r) {
        boolean hov = inside(mxPos, myPos, x, y, w, h);
        int bg = primary ? (hov ? 0xFF8279FF : ACCENT) : active ? ACCENT_DIM : hov ? HOVER : PANEL2;
        int bd = primary || active ? ACCENT : hov ? 0xFF3C4560 : BORDER;
        g.fill(x, y, x + w, y + h, bg);
        border(g, x, y, w, h, bd);
        String l = fit(label, w - 4);
        g.drawString(this.font, l, x + (w - this.font.width(l)) / 2, y + (h - 8) / 2 + 1,
            primary ? 0xFFFFFFFF : active ? TEXT : 0xFFB4BCD0, false);
        hits.add(new Hit(x, y, w, h, r));
    }

    private void fieldBg(GuiGraphics g, int x, int y, int w, int h, EditBox box) {
        g.fill(x, y, x + w, y + h, PANEL2);
        border(g, x, y, w, h, box != null && box.isFocused() ? ACCENT : BORDER);
    }

    private void border(GuiGraphics g, int x, int y, int w, int h, int c) {
        g.fill(x, y, x + w, y + 1, c);
        g.fill(x, y + h - 1, x + w, y + h, c);
        g.fill(x, y, x + 1, y + h, c);
        g.fill(x + w - 1, y, x + w, y + h, c);
    }

    private void label(GuiGraphics g, String s, int x, int y) {
        g.drawString(this.font, s, x, y, MUTED, false);
    }

    private void scrollbar(GuiGraphics g, int x, int y, int h, int content, int scroll) {
        if (content <= h) return;
        int thumb = Math.max(12, h * h / content);
        int ty = y + (int) ((long) (h - thumb) * scroll / (content - h));
        g.fill(x, ty, x + 2, ty + thumb, 0xFF4A5372);
    }

    private static boolean inside(int px, int py, int x, int y, int w, int h) {
        return px >= x && px < x + w && py >= y && py < y + h;
    }

    private String fit(String s, int maxW) {
        if (maxW <= 0) return "";
        if (this.font.width(s) <= maxW) return s;
        while (!s.isEmpty() && this.font.width(s + "..") > maxW) s = s.substring(0, s.length() - 1);
        return s + "..";
    }
}
